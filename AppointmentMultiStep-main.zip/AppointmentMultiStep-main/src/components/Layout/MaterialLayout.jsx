import React from "react";
import { Paper, CssBaseline } from "@material-ui/core";
// import { ThemeProvider } from "@material-ui/core/styles";
import { ThemeProvider } from "@material-ui/styles";
// import Header from '../Header';
// import Footer from '../Footer';
import { theme, useStyle } from "./styles";
export default function MaterialLayout(props) {
  const { children, activeStepColor } = props;
  const classes = useStyle();
  return (
    <>
      <CssBaseline />
      {/* <Header /> */}
      <div className={classes.root}>
        <Paper
          style={{
            backgroundColor: activeStepColor,
          }}
          className={classes.paper}
        >
          {" "}
          {children}
        </Paper>
      </div>
      {/* <Footer /> */}
    </>
  );
}
