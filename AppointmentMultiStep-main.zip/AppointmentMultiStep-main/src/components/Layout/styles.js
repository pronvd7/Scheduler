import { responsiveFontSizes, makeStyles } from "@material-ui/core/styles";
import { createTheme } from "@mui/material/styles";

const useStyle = makeStyles((theme) => ({
  root: {
    height: "100vh",
    width: "35rem",
    marginLeft: "auto",
    marginRight: "0px",
    backgroundColor: theme.palette.background.default,
    boxShadow: "-12px 0px 11px rgba(0, 0, 0, 0.15)",
    color: theme.palette.text.primary,
    [theme.breakpoints.down(600)]: {
      width: "100%",
      overflowY: "auto",
      background: "#ffffff",
    },
  },
  paper: {
    height: "100%",
    padding: "0",
    marginTop: "0",
    marginBottom: "0",
    borderRadius: "0",
    border: "none",
    boxShadow: "none",
    [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
      padding: "0",
      marginTop: "0",
      marginBottom: "0",
    },
  },
}));
export { useStyle };
