import React, { useState } from "react";
// import Autocomplete from "@material-ui/lab/Autocomplete";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import IconButton from "@material-ui/core/IconButton";

import { SearchIcon } from "../Icons";
import appointmentFormStyle from "../AppointmentForm/styles";
import { at } from "lodash";
import { useField, useFormikContext } from "formik";

const stateList = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "District Of Columbia",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
];

const AutocompleteWithSearchIcon = (props) => {
  const classes = appointmentFormStyle();
  const formik = useFormikContext();
  const { setFieldValue } = formik;
  const [field, meta, helper] = useField(props);
  const { value: selectedValue } = field;
  const { setValue } = helper;

  function _renderHelperText() {
    const [touched, error] = at(meta, "touched", "error");
    if (touched && error) {
      return error;
    }
  }

  return (
    <Autocomplete
      freeSolo
      id="state"
      name="state"
      className={`${classes.w100} ${classes.textFieldDiv}`}
      value={selectedValue}
      options={stateList} // replace with your own options
      getOptionLabel={(option) => option.toString()}
      onInputChange={(event, newInputValue) => {
        setValue(newInputValue);
        if (formik?.values?.state !== newInputValue) {
          //if state value get changed validate addres again
          setFieldValue("isValidAddress", "onEdit");
        }
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          variant="outlined"
          label="State"
          value={selectedValue}
          autoComplete="off"
          error={meta.touched && meta.error && true}
          helperText={_renderHelperText()}
          {...field}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <IconButton edge="end" aria-label="search">
                <SearchIcon />
              </IconButton>
            ),
          }}
        />
      )}
    />
  );
};
export default AutocompleteWithSearchIcon;
