import React, { useEffect, useState } from "react";
import CustomerType from "./CustomerType";
import CustomerDetail from "./CustomerDetail";
import CustomerAddress from "./CustomerAddress";
import { useFormikContext } from "formik";
import {
  clientDetailSchema,
  clientAddressSchema,
  existClientDetailSchema,
} from "../FormModel/clientValidationSchema";
export default function Client(props) {
  const {
    setCurrentValidationSchema,
    clientActiveStep,
    _handleNext,
    setIsNextdisabled,
    setNextHide,
  } = props;

  const { values } = useFormikContext();

  useEffect(() => {
    if (clientActiveStep === 1 && values?.customerType === "newCustomer") {
      setCurrentValidationSchema(clientDetailSchema);
    } else if (
      clientActiveStep === 2 &&
      values?.customerType === "newCustomer"
    ) {
      setCurrentValidationSchema(clientAddressSchema);
    } else if (
      clientActiveStep === 1 &&
      values?.customerType === "existingCustomer"
    ) {
      setCurrentValidationSchema(existClientDetailSchema);
    } else {
      setCurrentValidationSchema(null);
    }
  }, [clientActiveStep, values?.customerType]);

  // console.log(clientDescriptionSchema);
  function _renderStepContent(step) {
    switch (step) {
      case 0:
        return (
          <CustomerType
            setNextHide={setNextHide}
            _handleNextStep={_handleNext}
          />
        );
      case 1:
        return (
          <CustomerDetail
            setIsNextdisabled={setIsNextdisabled}
            setNextHide={setNextHide}
          />
        );
      case 2:
        return (
          <CustomerAddress
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
            setCurrentValidationSchema={setCurrentValidationSchema}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  }

  return (
    <React.Fragment>{_renderStepContent(clientActiveStep)}</React.Fragment>
  );
}
