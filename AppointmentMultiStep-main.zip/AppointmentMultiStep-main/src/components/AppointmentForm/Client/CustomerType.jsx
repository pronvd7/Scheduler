import React, { useEffect, useState, useContext } from "react";
import { Typography, Button, Box } from "@material-ui/core";
import { SvgIcon, Avatar } from "@mui/material";
import appointmentFormStyle from "../styles";
import { SchedulerContext } from "../../../context/schedulerContext";
import { useFormikContext } from "formik";

export default function CustomerType(props) {
  const classes = appointmentFormStyle();
  const { setNextHide, _handleNextStep } = props;
  const { setFieldValue } = useFormikContext();
  const { schedulerData } = useContext(SchedulerContext);

  useEffect(() => {
    setNextHide(true);
  }, []);

  return (
    <React.Fragment>
      <div className={classes.formDivWithHeight}>
        <div className={classes.rectangle}>
          <div
            style={{
              textAlign: "center",
            }}
          >
            {schedulerData?.logoUrl !== undefined &&
            schedulerData?.logoUrl !== "" ? (
              <Box style={{ height: "120px" }}>
                <img
                  src={schedulerData?.logoUrl}
                  alt="SVG Image"
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "contain",
                  }}
                />
              </Box>
            ) : (
              <Typography className={classes.fixBox} variant="h5">
                {" "}
                FIX
              </Typography>
            )}
          </div>
        </div>
        <div style={{ gap: "1rem" }} className={classes.buttonsWrap}>
          <Button
            onClick={() => {
              setFieldValue("customerType", "existingCustomer");
              _handleNextStep();
            }}
            className={`exist filled ${classes.themeBtn}`}
            style={{
              background: schedulerData?.colorCode,
              border: `1px solid ${schedulerData?.colorCode}`,
              textTransform: "none",
              fontSize: "1rem",
              lineHeight: "1.25rem",
              fontWeight: "600",
              padding: "12px 18px !important",
            }}
          >
            I am an existing customer
          </Button>
          <Button
            onClick={() => {
              setFieldValue("customerType", "newCustomer");
              _handleNextStep();
            }}
            className={`grayBtn ${classes.themeBtn}`}
            style={{
              background: "#EDF1F7",
              color: "black",
              textTransform: "none",
              fontSize: "1rem",
              lineHeight: "1.25rem",
              fontWeight: "600",
              padding: "12px 18px !important",
            }}
          >
            I am a new customer
          </Button>
        </div>
      </div>
    </React.Fragment>
  );
}
