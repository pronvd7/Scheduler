import React, { useEffect, useState } from "react";
import NewCustomerAddress from "./ClientInfo/NewCustomerAddress";
import ExistingCustomerAddress from "./ClientInfo/ExistingCustomerAddress";
import { useFormikContext } from "formik";

const CustomerAddress = (props) => {
  const { setIsNextdisabled, _handleNext, setCurrentValidationSchema } = props;
  const { values } = useFormikContext();
  return (
    <>
      {values?.customerType === "newCustomer" ? (
        <NewCustomerAddress
          _handleNext={_handleNext}
          setIsNextdisabled={setIsNextdisabled}
        />
      ) : (
        <ExistingCustomerAddress
          setIsNextdisabled={setIsNextdisabled}
          _handleNext={_handleNext}
          setCurrentValidationSchema={setCurrentValidationSchema}
        />
      )}
    </>
  );
};

export default CustomerAddress;
