import React, { useEffect, useState } from "react";
import { Typography } from "@material-ui/core";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import appointmentFormStyle from "../../styles";
import { EmailIcon, ProfileIcon, PhoneIcon } from "../../../Icons";
import { Box, SvgIcon } from "@mui/material";

import { useFormikContext } from "formik";

const NewCustomerDetail = (props) => {
  const classes = appointmentFormStyle();
  const { setIsNextdisabled } = props;
  const formik = useFormikContext();

  useEffect(() => {
    setIsNextdisabled(false);
  }, []);

  return (
    <div className={classes.formDivWithHeight}>
      <Typography className={`mb-4 ${classes.headingSix}`} variant="h6">
        New customer
        <hr className={classes.formTitleHr} style={{ marginLeft: "0" }}></hr>
      </Typography>
      <div className={classes.formTitleDiv}>
        <Box className={classes.formInstructionTypo} component="p" variant="p">
          Please enter your details below
        </Box>
        <TextField
          variant="outlined"
          id="cName"
          name="cName"
          label="First name and last name"
          placeholder="First name and last name"
          className={classes.textFieldDiv}
          value={formik.values.cName}
          onChange={formik.handleChange}
          error={formik.touched.cName && Boolean(formik.errors.cName)}
          helperText={formik.touched.cName && formik.errors.cName}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SvgIcon component={ProfileIcon} />
              </InputAdornment>
            ),
          }}
        />
        <TextField
          variant="outlined"
          id="phoneNumber"
          label="Phone number"
          name="phoneNumber"
          placeholder="Phone number"
          className={classes.textFieldDiv}
          value={formik.values.phoneNumber}
          onChange={formik.handleChange}
          error={
            formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)
          }
          helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SvgIcon component={PhoneIcon} />
              </InputAdornment>
            ),
          }}
        />

        <TextField
          variant="outlined"
          id="email"
          label="Email address"
          name="email"
          placeholder="Email address"
          className={classes.textFieldDiv}
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.touched.email && Boolean(formik.errors.email)}
          helperText={formik.touched.email && formik.errors.email}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SvgIcon component={EmailIcon} />
              </InputAdornment>
            ),
          }}
        />
      </div>
    </div>
  );
};

export default NewCustomerDetail;
