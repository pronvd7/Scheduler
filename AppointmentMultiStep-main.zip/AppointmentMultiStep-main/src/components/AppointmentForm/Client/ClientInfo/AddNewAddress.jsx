import React, { useEffect, useContext } from "react";
import { Button, Typography } from "@material-ui/core";
import TextField from "@mui/material/TextField";
import AutocompleteWithSearchIcon from "../../../FormFields/AutocompleteWithSearchIcon";
import Autocomplete, { usePlacesWidget } from "react-google-autocomplete";
import appointmentFormStyle from "../../styles";
import ErrorDetail from "./ErrorDetail";
import { SvgIcon } from "@mui/material";
import { CrossIcon } from "../../../Icons";
import { useState } from "react";
import { CheckboxField } from "../../../FormFields";
import { SchedulerContext } from "../../../../context/schedulerContext";
import { Box } from "@mui/material";
import { useFormikContext, useForm } from "formik";

const AddNewAddress = (props) => {
  const { _handleNext, setCurrentValidationSchema, setShowResults } = props;
  const classes = appointmentFormStyle();
  const formik = useFormikContext();
  const { schedulerData } = useContext(SchedulerContext);

  const { setFieldValue, handleSubmit } = formik;
  const [isAddressCorrectClicked, setIsAddressCorrectClicked] = useState(false);

  function _handleOnEdit() {
    setFieldValue("isValidAddress", "onEdit");
  }

  function fillInAddress(address_components) {
    let address1 = "";
    let postcode = "";

    address_components?.map((component) => {
      // @ts-ignore remove once typings fixed
      const componentType = component.types[0];

      switch (componentType) {
        case "street_number": {
          address1 = `${component.long_name} ${address1}`;
          formik.setFieldValue("streetAddress", address1);
          break;
        }

        case "route": {
          address1 += component.long_name;
          formik.setFieldValue("streetAddress", address1);
          break;
        }

        case "postal_code": {
          postcode = `${component.long_name}${postcode}`;
          formik.setFieldValue("zipCode", postcode);
          break;
        }

        case "postal_code_suffix": {
          postcode = `${postcode}-${component.long_name}`;

          break;
        }

        case "locality":
          formik.setFieldValue("city", component.long_name);
          break;

        case "administrative_area_level_1": {
          formik.setFieldValue("state", component.long_name);
          break;
        }

        case "country":
          //console.log(component.long_name, "Country");
          break;
      }
    });
  }

  const { ref } = usePlacesWidget({
    apiKey: process.env.REACT_APP_GOOGLE_API_KEY,
    onPlaceSelected: (place) => {
      fillInAddress(place?.address_components);
    },
    options: {
      componentRestrictions: { country: "us" },
      fields: ["address_components", "formatted_address", "geometry", "name"],
      strictBounds: false,
      types: ["address"],
    },
  });

  return (
    <Box
      className={classes.overlay}
      style={{ zIndex: "99" }}
      component="div"
      sx={{
        position: "absolute",
        top: "0",
        right: "0",
        bottom: "0",
        left: "0",
        margin: "auto",
        zIndex: "1",
      }}
    >
      <Box
        component="div"
        className={classes.popupaddress}
        sx={{
          maxWidth: ["100%"],
          boxShadow: "0px 14px 34px rgba(0, 0, 0, 0.25)",
          padding: "7px",
        }}
      >
        <Box
          onClick={() => setShowResults(false)}
          style={{
            position: "absolute",
            width: "20px",
            height: "20px",
            right: "30px",
            fontWeight: "300",
            fontSize: "20px",
            lineHeight: "20px",
            display: "flex",
            alignItems: "center",
            textAlign: "right",
          }}
        >
          <SvgIcon component={CrossIcon} />
        </Box>
        <div className={classes.formDivWithHeight}>
          <Box component="div" className={classes.formTitleDiv}>
            <Box
              className={classes.formInstructionTypo}
              component="p"
              variant="p"
              fontWeight="bold"
            >
              Please search for your address below
            </Box>
            <TextField
              fullWidth
              className={classes.textFieldDiv}
              variant="outlined"
              inputRef={ref}
              id="autoCompleteAddress"
              name="autoCompleteAddress"
              autoComplete="off"
              placeholder="Search Address..."
              onChange={(event) => {
                //  console.log(event);
              }}
            />
            <Typography
              variant="body1"
              style={{ display: "flex", alignItems: "center" }}
            >
              <span className={classes.orDivideSpan}></span>
              OR
              <span className={classes.orDivideSpan}></span>
            </Typography>
            <Box
              className={classes.formInstructionTypo}
              component="p"
              variant="p"
              fontWeight="bold"
            >
              If your address is not found, please enter it below
            </Box>

            <TextField
              className={classes.textFieldDiv}
              id="streetAddress"
              name="streetAddress"
              label="Street Address"
              variant="outlined"
              value={formik.values.streetAddress}
              onChange={(event) => {
                formik.handleChange(event);
                _handleOnEdit();
              }}
              error={
                formik.touched.streetAddress &&
                Boolean(formik.errors.streetAddress)
              }
              helperText={
                formik.touched.streetAddress && formik.errors.streetAddress
              }
            />

            <TextField
              className={classes.textFieldDiv}
              id="unitNumber"
              name="unitNumber"
              label="Apartment / Unit"
              variant="outlined"
              value={formik.values.unitNumber}
              onChange={(event) => {
                formik.handleChange(event);
                _handleOnEdit();
              }}
              error={
                formik.touched.unitNumber && Boolean(formik.errors.unitNumber)
              }
              helperText={formik.touched.unitNumber && formik.errors.unitNumber}
            />

            <div className={classes.flexFieldWrap}>
              <div className="childField">
                <TextField
                  id="city"
                  label="City"
                  name="city"
                  variant="outlined"
                  className={`${classes.w100} ${classes.textFieldDiv}`}
                  value={formik.values.city}
                  onChange={(event) => {
                    formik.handleChange(event);
                    _handleOnEdit();
                  }}
                  error={formik.touched.city && Boolean(formik.errors.city)}
                  helperText={formik.touched.city && formik.errors.city}
                />
              </div>
              <div className="childField">
                <AutocompleteWithSearchIcon name="state" label="State" />
              </div>
            </div>
            <div className={`checked ${classes.flexFieldWrapper}`}>
              <div className="childField">
                <TextField
                  className={`${classes.w100} ${classes.textFieldDiv}`}
                  id="outlined-basic"
                  name="zipCode"
                  label="Zip Code"
                  variant="outlined"
                  value={formik.values.zipCode}
                  onChange={(event) => {
                    formik.handleChange(event);
                    _handleOnEdit();
                  }}
                  error={
                    formik.touched.zipCode && Boolean(formik.errors.zipCode)
                  }
                  helperText={formik.touched.zipCode && formik.errors.zipCode}
                />
              </div>
              <div className="childField">
                <CheckboxField
                  className={classes.checkBoxClass}
                  name="isOwner"
                  label="I own this residence"
                />
              </div>
            </div>

            <div className={classes.ButtonAddress}>
              <Button
                className={`outlined ${classes.themeBtn}`}
                style={{
                  background: schedulerData?.colorCode, //"#007BFF",
                  color: "#fff",
                  border: `1px solid ${schedulerData?.colorCode}`,
                }}
                onClick={() => {
                  setFieldValue("isAddNewAddress", true);
                  handleSubmit();
                  //  _handleNext(formik.values, formik);
                }}
              >
                Add Address
              </Button>
            </div>
            <div>
              {formik.values.isValidAddress === "inValid" ? (
                <ErrorDetail
                  setValidAddress={() => {
                    setFieldValue("isValidAddress", "valid");
                    setIsAddressCorrectClicked(true);
                    //after address set to valid useEffect will triger to move to next step
                  }}
                  setEditAddress={() =>
                    setFieldValue("isValidAddress", "onEdit")
                  }
                  invalidAddressError={formik.values.invalidAddressError}
                  formattedAddress={formik.values.formattedAddress}
                />
              ) : null}
            </div>
          </Box>
        </div>
      </Box>
    </Box>
  );
};

export default AddNewAddress;
