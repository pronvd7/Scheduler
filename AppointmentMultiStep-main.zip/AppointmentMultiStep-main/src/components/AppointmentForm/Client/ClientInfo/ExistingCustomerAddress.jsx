import React from "react";
import { Button, Typography } from "@material-ui/core";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import { Box } from "@mui/material";
import { useState } from "react";
import appointmentFormStyle from "../../styles";
import AddNewAddress from "./AddNewAddress";

import { useFormikContext } from "formik";
import { useEffect } from "react";
import { clientAddressSchema } from "../../FormModel/clientValidationSchema";
//import NewCustomerAddress from "./NewCustomerAddress";

const ExistingCustomerAddress = (props) => {
  const { setIsNextdisabled, _handleNext, setCurrentValidationSchema } = props;
  const classes = appointmentFormStyle();
  const formik = useFormikContext();
  const { setFieldValue, values } = formik;
  const [addressList, setAddressList] = useState(
    values?.addresses ? values?.addresses : []
  );
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    if (showResults) {
      setCurrentValidationSchema(clientAddressSchema);
    } else {
      setCurrentValidationSchema(null);
    }
  }, [showResults]);

  useEffect(() => {
    setIsNextdisabled(true);
  }, []);

  const handleChange = (event) => {
    setFieldValue("addressId", event?.target?.value);
    setIsNextdisabled(false);
  };

  return (
    <Box component="div" className={classes.formDivWithHeight}>
      <Typography variant="h6" className={`mb-4 ${classes.headingSix}`}>
        Address where our team is needed
        <hr className={classes.formTitleHr} style={{ marginLeft: "0" }}></hr>
      </Typography>
      <Box
        component="div"
        className={classes.formTitleDiv}
        sx={{
          gap: "1.5rem",
          display: "inline-flex",
        }}
      >
        {addressList?.length > 0 && (
          <RadioGroup
            style={{
              gap: "1.5rem",
              paddingTop: ".875rem",
            }}
            name="use-radio-group"
            // defaultValue="first"
          >
            {addressList?.map((address) => {
              // Extract address components
              const street = address?.address?.street || "";
              const city = address?.address?.city || "";
              const state = address?.address?.state || "";
              const postalCode = address?.address?.zip || "";
              const unit =
                address?.address?.unit !== null ? address?.address?.unit : "";
              // Concatenate address components
              const addressString = [street, unit, city, state, postalCode]
                .filter(Boolean)
                .join(", ");

              return (
                <FormControlLabel
                  key={address?.id}
                  className={classes.formAddressRadio}
                  value={address?.id}
                  label={addressString}
                  onChange={(event) => handleChange(event)}
                  control={<Radio />}
                />
              );
            })}
          </RadioGroup>
        )}
        <Button
          className={`outlined newAddress ${classes.themeBtn}`}
          onClick={() => setShowResults(true)}
        >
          ADD NEW ADDRESS
        </Button>
        {showResults ? (
          <AddNewAddress
            _handleNext={_handleNext}
            setCurrentValidationSchema={setCurrentValidationSchema}
            setShowResults={setShowResults}
          />
        ) : null}
      </Box>
    </Box>
  );
};

export default ExistingCustomerAddress;
