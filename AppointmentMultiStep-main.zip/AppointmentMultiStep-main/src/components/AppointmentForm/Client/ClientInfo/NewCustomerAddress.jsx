import React, { useEffect, useContext } from "react";
import { Button, Typography } from "@material-ui/core";
import Autocomplete, { usePlacesWidget } from "react-google-autocomplete";
import TextField from "@mui/material/TextField";
import AutocompleteWithSearchIcon from "../../../FormFields/AutocompleteWithSearchIcon";
import appointmentFormStyle from "../../styles";
import ErrorDetail from "./ErrorDetail";
import { useState } from "react";
import { CheckboxField } from "../../../FormFields";

import { Box } from "@mui/material";

import { useFormikContext } from "formik";

const NewCustomerAddress = (props) => {
  const { _handleNext } = props;
  const classes = appointmentFormStyle();

  const formik = useFormikContext();

  const { setFieldValue } = formik;

  const [isAddressCorrectClicked, setIsAddressCorrectClicked] = useState(false);

  function _handleOnEdit() {
    setFieldValue("isValidAddress", "onEdit");
  }

  useEffect(() => {
    if (
      formik?.values?.isValidAddress === "valid" &&
      isAddressCorrectClicked === true
    ) {
      _handleNext(formik.values, formik);
    }
  }, [formik?.values?.isValidAddress, isAddressCorrectClicked]);

  function fillInAddress(address_components) {
    let address1 = "";
    let postcode = "";

    address_components?.map((component) => {
      // @ts-ignore remove once typings fixed
      const componentType = component.types[0];

      switch (componentType) {
        case "street_number": {
          address1 = `${component.long_name} ${address1}`;
          formik.setFieldValue("streetAddress", address1);
          break;
        }

        case "route": {
          address1 += component.long_name;
          formik.setFieldValue("streetAddress", address1);
          break;
        }

        case "postal_code": {
          postcode = `${component.long_name}${postcode}`;
          formik.setFieldValue("zipCode", postcode);
          break;
        }

        case "postal_code_suffix": {
          postcode = `${postcode}-${component.long_name}`;

          break;
        }

        case "locality":
          formik.setFieldValue("city", component.long_name);
          break;

        case "administrative_area_level_1": {
          formik.setFieldValue("state", component.long_name);
          break;
        }

        case "country":
          // console.log(component.long_name, "Country");
          break;
      }
    });
  }

  const { ref } = usePlacesWidget({
    apiKey: process.env.REACT_APP_GOOGLE_API_KEY,
    onPlaceSelected: (place) => {
      fillInAddress(place?.address_components);
    },
    options: {
      componentRestrictions: { country: "us" },
      fields: ["address_components", "formatted_address", "geometry", "name"],
      strictBounds: false,
      types: ["address"],
    },
  });

  return (
    <div className={classes.formDivWithHeight}>
      <Typography variant="h6" className={`mb-4 ${classes.headingSix}`}>
        Address where our team is needed
        <hr className={classes.formTitleHr} style={{ marginLeft: "0" }}></hr>
      </Typography>
      <Box component="div" className={classes.formTitleDiv}>
        <Box
          className={classes.formInstructionTypo}
          fontWeight="bold"
          component="p"
          variant="p"
        >
          Please search for your address below
        </Box>
        <TextField
          fullWidth
          className={classes.textFieldDiv}
          variant="outlined"
          inputRef={ref}
          id="autoCompleteAddress"
          name="autoCompleteAddress"
          placeholder="Search Address..."
          autoComplete="off"
          onChange={(event) => {
            //  console.log(event);
          }}
        />

        <Typography
          variant="body1"
          style={{ display: "flex", alignItems: "center" }}
        >
          <span className={classes.orDivideSpan}></span>
          or
          <span className={classes.orDivideSpan}></span>
        </Typography>
        <Box
          className={classes.formInstructionTypo}
          fontWeight="bold"
          component="p"
          variant="p"
        >
          If your address is not found, please enter it below
        </Box>
        <TextField
          className={classes.textFieldDiv}
          id="streetAddress"
          name="streetAddress"
          label="Street Address"
          variant="outlined"
          value={formik.values.streetAddress}
          onChange={(event) => {
            formik.handleChange(event);
            _handleOnEdit();
          }}
          error={
            formik.touched.streetAddress && Boolean(formik.errors.streetAddress)
          }
          helperText={
            formik.touched.streetAddress && formik.errors.streetAddress
          }
        />
        <TextField
          className={classes.textFieldDiv}
          id="unitNumber"
          name="unitNumber"
          label="Apartment / Unit"
          variant="outlined"
          value={formik.values.unitNumber}
          onChange={(event) => {
            formik.handleChange(event);
            _handleOnEdit();
          }}
          error={formik.touched.unitNumber && Boolean(formik.errors.unitNumber)}
          helperText={formik.touched.unitNumber && formik.errors.unitNumber}
        />
        <div className={classes.flexFieldWrap}>
          <div className="childField">
            <TextField
              id="city"
              label="City"
              name="city"
              variant="outlined"
              className={`${classes.w100} ${classes.textFieldDiv}`}
              value={formik.values.city}
              onChange={(event) => {
                formik.handleChange(event);
                _handleOnEdit();
              }}
              error={formik.touched.city && Boolean(formik.errors.city)}
              helperText={formik.touched.city && formik.errors.city}
            />
          </div>
          <div className="childField">
            <AutocompleteWithSearchIcon name="state" label="state" />
          </div>
        </div>
        <div className={`checked ${classes.flexFieldWrap}`}>
          <div className="childField">
            <TextField
              className={`${classes.w100} ${classes.textFieldDiv}`}
              id="outlined-basic"
              name="zipCode"
              label="Zip Code"
              variant="outlined"
              value={formik.values.zipCode}
              onChange={(event) => {
                formik.handleChange(event);
                _handleOnEdit();
              }}
              error={formik.touched.zipCode && Boolean(formik.errors.zipCode)}
              helperText={formik.touched.zipCode && formik.errors.zipCode}
            />
          </div>
          <div className="childField">
            <CheckboxField
              className={classes.checkBoxClass}
              name="isOwner"
              label="I own this residence"
            />
          </div>
        </div>
        <div>
          {formik.values.isValidAddress === "inValid" ? (
            <ErrorDetail
              setValidAddress={() => {
                setFieldValue("isValidAddress", "valid");
                setIsAddressCorrectClicked(true);
                //after address set to valid useEffect will triger to move to next step
              }}
              setEditAddress={() => setFieldValue("isValidAddress", "onEdit")}
              invalidAddressError={formik.values.invalidAddressError}
              formattedAddress={formik.values.formattedAddress}
            />
          ) : null}
        </div>
      </Box>
    </div>
  );
};

export default NewCustomerAddress;
