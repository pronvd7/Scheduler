import React, { useEffect, useState } from "react";
import { Typography, Link } from "@material-ui/core";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import InputMask from "react-input-mask";
import { PhoneIcon, GreeTikIcon, WarningIcon } from "../../../Icons";
import { SvgIcon } from "@mui/material";
import { useMutation } from "react-query";
import appointmentFormStyle from "../../styles";
import { useFormikContext } from "formik";
import { getExistingCustomer } from "../../../../api/services";

const ExistingCustomerDetail = (props) => {
  const classes = appointmentFormStyle();
  const formik = useFormikContext();
  const { setFieldValue, values, isValid } = formik;
  const { setIsNextdisabled } = props;
  const [isAccountExist, setIsAccountExist] = useState(null); //enum[exist, notExist]

  const {
    mutateAsync: mutateAsyncGetExistingCustomer,
    isLoading,
    error,
    data,
  } = useMutation(getExistingCustomer);

  useEffect(() => {
    if (isValid && values?.accountPhoneNumber.length >= 12) {
      mutateAsyncGetExistingCustomer(values?.accountPhoneNumber)
        .then((response) => {
          if (response?.customerData?.id) {
            setFieldValue("addresses", response?.addresses);
            setFieldValue("customerData", response?.customerData);
            setFieldValue("appointmentObj", response?.appointmentObj);
            setIsAccountExist("exist");
            setIsNextdisabled(false);
          } else {
            setIsAccountExist("notExist");
            setIsNextdisabled(true);
          }
        })
        .catch((error) => {
          setIsAccountExist("notExist");
          setIsNextdisabled(false);
          console.log(error, "error");
        });
    } else {
      setIsNextdisabled(true);
    }
  }, [isValid, values?.accountPhoneNumber]);

  return (
    <div className={classes.formDivWithHeight}>
      <Typography variant="h6" className={`mb-4 ${classes.headingSix}`}>
        Existing customer
        <hr className={classes.formTitleHr} style={{ marginLeft: "0" }}></hr>
      </Typography>

      <div className={classes.formTitleDiv}>
        <Typography className={classes.formInstructionTypo} variant="subtitle1">
          Please enter your account phone number
        </Typography>
        <div className={classes.formAccountDiv}>
          <InputMask
            mask="999 999 9999"
            maskplaceholder={null}
            value={formik.values.accountPhoneNumber}
            onChange={formik.handleChange}
            maskChar={null}
          >
            {(inputProps) => (
              <TextField
                {...inputProps}
                type="tel"
                name="accountPhoneNumber"
                id="input-with-icon-textfield"
                label="Account phone number"
                placeholder="Account phone number"
                error={
                  formik.touched.accountPhoneNumber &&
                  Boolean(formik.errors.accountPhoneNumber)
                }
                helperText={
                  formik.touched.accountPhoneNumber &&
                  formik.errors.accountPhoneNumber
                }
                className={classes.textFieldDiv}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SvgIcon component={PhoneIcon} />
                    </InputAdornment>
                  ),
                  endAdornment: isLoading ? (
                    <InputAdornment position="start">
                      <CircularProgress
                        variant="indeterminate"
                        disableShrink
                        sx={{
                          color: formik?.values?.siteColor,
                          animationDuration: "550ms",
                        }}
                        thickness={4}
                        value={100}
                        size={25}
                      />
                    </InputAdornment>
                  ) : isAccountExist === "notExist" ? (
                    <InputAdornment position="start">
                      <SvgIcon component={WarningIcon} />
                    </InputAdornment>
                  ) : isAccountExist === "exist" ? (
                    <InputAdornment position="start">
                      <SvgIcon component={GreeTikIcon} />
                    </InputAdornment>
                  ) : null,
                }}
              />
            )}
          </InputMask>
          {isAccountExist === "notExist" && (
            <Typography
              className={classes.formDbResponseTypo}
              variant="subtitle1"
            >
              We couldn’t find this phone number in our database! If you’re not
              a customer yet, please{" "}
              <Link
                onClick={() => setFieldValue("customerType", "newCustomer")}
                href="#"
              >
                click here to enter your details.
              </Link>
            </Typography>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExistingCustomerDetail;
