import React from "react";
import { Button, Typography } from "@material-ui/core";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import { List, ListItem, ListItemText, Box } from "@mui/material";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faCheck } from "@fortawesome/free-solid-svg-icons";
import { useFormikContext } from "formik";
import appointmentFormStyle from "../../styles";
function ErrorDetail(props) {
  const classes = appointmentFormStyle();
  const {
    setValidAddress,
    setEditAddress,
    formattedAddress,
    invalidAddressError,
  } = props;
  const formik = useFormikContext();

  return (
    <Box
      className={classes.overlay}
      style={{ zIndex: "99" }}
      component="div"
      sx={{
        position: "absolute",
        top: "0",
        right: "0",
        bottom: "0",
        left: "0",
        margin: "auto",
        zIndex: "1",
      }}
    >
      <Box
        component="div"
        className={classes.popupcard}
        sx={{
          maxWidth: ["100%", "28.5rem"],
          boxShadow: "0px 14px 34px rgba(0, 0, 0, 0.25)",
          padding: "1rem",
        }}
      >
        <Typography
          style={{ fontSize: "20px", fontFamily: "Poppins", fontWeight: "600" }}
          variant="h3"
        >
          Address not found
        </Typography>
        <List style={{ paddingBottom: "0px" }}>
          <ListItem
            sx={{
              color: "#F84771",
              gap: "10px",
              paddingTop: "5px",
              paddingX: "0",
            }}
          >
            <WarningAmberRoundedIcon sx={{ marginBottom: "2rem" }} />
            <ListItemText>
              <Box
                component="span"
                sx={{
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontWeight: "400",
                  fontSize: "1rem",
                  lineHeight: "2rem",
                }}
              >
                {invalidAddressError
                  ? invalidAddressError
                  : `We couldn’t locate your address, please double check to avoid
                any errors.`}
              </Box>
            </ListItemText>
          </ListItem>
          <ListItem sx={{ gap: "10px", paddingTop: "0px", paddingX: "0" }}>
            <LocationOnOutlinedIcon
              className={classes.locationicon}
              sx={{ color: "#007BFF", marginBottom: "2rem" }}
            />
            <ListItemText>
              <Box
                component="span"
                sx={{
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontWeight: "400",
                  color: "#1F2327",
                  fontSize: "1rem",
                  lineHeight: "2rem",
                }}
              >
                {formattedAddress ? formattedAddress : ""}
              </Box>
            </ListItemText>
          </ListItem>
        </List>
        <Box
          component="div"
          sx={{
            display: "flex",
            justifyContent: ["center", "space-between"],
            flexWrap: "wrap",
            gap: ".875rem",
          }}
        >
          <Button
            className={`outlined ${classes.themeBtn}`}
            startIcon={<FontAwesomeIcon icon={faPencil} />}
            onClick={() => setEditAddress()}
          >
            Edit address
          </Button>
          <Button
            className={`filled ${classes.themeBtn}`}
            startIcon={<FontAwesomeIcon icon={faCheck} />}
            onClick={() => setValidAddress()}
            style={{
              background: formik?.values?.siteColor, //"#007BFF",
              border: `1px solid ${formik?.values?.siteColor}`,
            }}
          >
            Address is correct
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
export default ErrorDetail;
