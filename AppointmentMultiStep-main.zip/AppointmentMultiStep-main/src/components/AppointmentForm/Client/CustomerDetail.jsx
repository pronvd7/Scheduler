import React, { useEffect, useState } from "react";
import NewCustomerDetail from "./ClientInfo/NewCustomerDetail";
import ExistingCustomerDetail from "./ClientInfo/ExistingCustomerDetail";
import { useFormikContext } from "formik";
const CustomerDetail = (props) => {
  const { setIsNextdisabled, setNextHide } = props;
  const { values } = useFormikContext();

  useEffect(() => {
    setNextHide(false);
  }, []);

  return (
    <>
      {values?.customerType === "newCustomer" ? (
        <NewCustomerDetail setIsNextdisabled={setIsNextdisabled} />
      ) : (
        <ExistingCustomerDetail setIsNextdisabled={setIsNextdisabled} />
      )}
    </>
  );
};

export default CustomerDetail;
