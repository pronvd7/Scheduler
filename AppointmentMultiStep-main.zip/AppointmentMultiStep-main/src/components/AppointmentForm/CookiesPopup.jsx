import React, { useState } from "react";
import { Button } from "@material-ui/core";
import appointmentFormStyle from "../AppointmentForm/styles";
import { Box } from "@mui/material";
const CookiesPopup = (props) => {
  const classes = appointmentFormStyle();
  const { setIsShowCookies, isShowCookies } = props;
  const handleClose = () => {
    setIsShowCookies(false);
  };

  return (
    <Box component="div" className={classes.overlay} sx={{ zIndex: "99" }}>
      <Box component="div"
        className={classes.popupcard}      
        // anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        open={isShowCookies}
        onClose={handleClose}
      >
        <Box component="div" sx={{padding: ".5rem",}}>
          <h6            
            style={{
              fontSize: "1.25rem",
              lineHeight:'1.75rem',
              fontWeight: "600",
              margin: 0,
              paddingBottom: ".75rem",
            }}
          >
            Cookie Consent
          </h6>
          <span
            className="popuptext"
            style={{
              fontWeight: "400",
              fontSize: ".875rem",
              lineHeight:'1.25rem',
            }}
          >
            {" "}
            This website uses cookies to improve your experience. By using this
            site, you agree to our use of cookies.
          </span>
        </Box>
        <Box component="div"
          sx={{
            padding: "8px",
            textAlign: "end",
          }}
        >
          <Button
            className={`primary ${classes.themeBtn}`}              
            onClick={handleClose}> Accept
          </Button>
        </Box>
      </Box>
    </Box>
  );
};
export default CookiesPopup;
