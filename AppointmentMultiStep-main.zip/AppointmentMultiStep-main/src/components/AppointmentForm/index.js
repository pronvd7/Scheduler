import React, { useState, useEffect, useContext } from "react";
import {
  Stepper,
  Step,
  StepLabel,
  Box,
  Typography,
  Button,
  CircularProgress,
  Backdrop,
} from "@material-ui/core";
import { SvgIcon } from "@mui/material";
import { CrossIcon } from "../Icons";
import { Formik, Form } from "formik";
import ButtonAppBar from "./ButtonAppBar";
import Problem from "./Problem";
import Description from "./Description";
import Client from "./Client";
import Appointment from "./Appointment";
import Confirm from "./Confirm";
import Thanks from "./Thanks";
import CookiesPopup from "./CookiesPopup";
import { useMutation } from "react-query";

import { steps, problemSteps, clientSteps } from "./steps";
import useStyles from "./styles";
import { SchedulerContext } from "../../context/schedulerContext";

import { appointementInitialValues } from "./FormModel/appointementInitialValues";
import {
  validationAddress,
  createCustomer,
  createAddress,
  createAppointement,
  getAvailableSlots,
} from "../../api/services";

export default function AppointmentForm(props) {
  const { setActiveStepColor } = props;
  const { schedulerData, schedulerLoading, isSchedulerCompleted } = useContext(
    SchedulerContext
  );
  const classes = useStyles();
  const [isNextdisabled, setIsNextdisabled] = useState(true);
  const [nextHide, setNextHide] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [IsAvialableSlotsCompleted, setIsAvialableSlotsCompleted] = useState(
    false
  );
  const formId = "appiointmentForm";

  const [clientFormField, setClientFormField] = useState();
  // set default step for each
  const [activeStep, setActiveStep] = useState(0);
  const [problemActiveStep, setProblemActiveStep] = useState(0);
  const [descriptionActiveStep, setDescriptionActiveStep] = useState(0);
  const [clientActiveStep, setClientActiveStep] = useState(0);
  const [currentValidationSchema, setCurrentValidationSchema] = useState(null);

  const [availableSlots, setAvailableSlots] = useState({});
  const [availableDates, setAvailableDates] = useState([]);
  const [appointmentObj, setAppointmentObj] = useState({});

  const [descriptionSteps, setDescriptionSteps] = useState([
    "Diagnostic Fee",
    "Additional Info",
  ]);

  const isLastStep = activeStep === steps.length - 1;
  const isProblemLastStep = problemActiveStep === problemSteps.length - 1;
  const [isDescriptionLastStep, setIsDescriptionLastStep] = useState(
    descriptionActiveStep === descriptionSteps.length - 1
  );

  const isClientLastStep = clientActiveStep === clientSteps.length - 1;

  const addressParams = [
    "locality",
    "street_number",
    "route",
    "administrative_area_level_1",
    "postal_code",
    "country",
  ];

  const {
    mutateAsync: mutateAsyncAvailableSlots,
    isLoading: isSlotsLoading,
  } = useMutation("getAvailableSlots", getAvailableSlots, {
    onSettled: (data, error) => {
      setIsAvialableSlotsCompleted(true);
    },
  });

  const {
    mutateAsync: mutateAsyncValidateAddress,
    isLoading: isAddressLoading,
  } = useMutation("validationAddress", validationAddress);

  const {
    mutateAsync: mutateAsyncCreateAddress,
    isLoading: isCreateAddressLoading,
  } = useMutation("createAddress", createAddress);

  const {
    mutateAsync: mutateAsyncCreateCustomer,
    isLoading: isCreateCustomerLoading,
  } = useMutation("createCustomer", createCustomer);

  const {
    mutateAsync: mutateAsyncCreateAppointement,
    isLoading: isCreateAppointementLoading,
  } = useMutation("createAppointement", createAppointement);

  useEffect(() => {
    if (
      isCreateCustomerLoading ||
      isAddressLoading ||
      isCreateAddressLoading ||
      isCreateAppointementLoading ||
      isSlotsLoading
    ) {
      setIsLoading(true);
    } else {
      setIsLoading(false);
    }
  }, [
    isCreateCustomerLoading,
    isAddressLoading,
    isCreateAddressLoading,
    isCreateAppointementLoading,
    isSlotsLoading,
  ]);

  useEffect(() => {
    setIsDescriptionLastStep(
      descriptionActiveStep === descriptionSteps.length - 1
    );
  }, [descriptionSteps, descriptionActiveStep]);
  /**
   *
   * @param {*} values
   * Description: This function is used for fetch the appointment times
   */
  async function fetchAvailableSlots(values) {
    let appointmentObj = "";
    if (values?.addressId !== null && values?.addressId !== "") {
      appointmentObj = {
        ...values?.appointmentObj,
        addressId: values?.addressId,
      };
    } else {
      appointmentObj = values?.appointmentObj;
    }

    const remType =
      values?.selectedData?.remType !== ""
        ? values?.selectedData?.remType
        : values?.selectedData?.serviceType;

    const payload = {
      jobType: values?.selectedData?.jobType,
      rem: remType?.toLowerCase(),
      appointmentObj,
    };
    await mutateAsyncAvailableSlots(payload)
      .then((getAvailableSlotResp) => {
        setAvailableDates(Object.keys(getAvailableSlotResp?.calendarTimes));
        setAvailableSlots(getAvailableSlotResp?.calendarTimes);
        setAppointmentObj(getAvailableSlotResp?.appointmentObj);
      })
      .catch((error) => {
        console.log(error, "error");
      });
  }

  /**
   *
   * @param {*} values
   * @param {*} actions
   * Description: This function is used for valid address that is entered in client address form
   */

  const _hanldeIsValidAddress = async (values, actions) => {
    const payload = {
      addressLines: [`${values?.streetAddress}`],
      locality: values?.city,
      //unitNumber: values?.unitNumber,
      administrativeArea: values?.state,
      postalCode: values?.zipCode,
      regionCode: "US",
    };

    await mutateAsyncValidateAddress(payload)
      .then((response) => {
        if (response?.error) {
          actions?.setFieldValue("isValidAddress", "inValid");
          actions?.setFieldValue(
            "invalidAddressError",
            response?.error?.message
          );
          return false;
        } else {
          const address = response?.result?.address;
          const formattedAddress = address?.formattedAddress;
          const postalAddress = address?.postalAddress;
          const unconfirmedComponentTypes = address?.unconfirmedComponentTypes;
          if (
            addressParams.some((item) =>
              unconfirmedComponentTypes.includes(item)
            )
          ) {
            actions?.setFieldValue("isValidAddress", "inValid");
            actions?.setFieldValue("invalidAddressError", ""); // default error
            actions?.setFieldValue("formattedAddress", formattedAddress);
            actions?.setFieldValue("postalAddress", postalAddress);
            return false;
          } else {
            actions?.setFieldValue("isValidAddress", "valid");
            actions?.setFieldValue("formattedAddress", formattedAddress);
            actions?.setFieldValue("postalAddress", postalAddress);
            return true;
          }
        }
      })
      .catch((error) => {
        actions?.setFieldValue("isValidAddress", "inValid");
        actions?.setFieldValue("invalidAddressError", error?.error?.message);
        return false;
      });
  };

  /**
   * function _handleCreateCustomer()
   * @param {*} values
   * @param {*} actions
   * Descripiton: This function is used to create a customer
   */
  const _handleCreateCustomer = async (values, actions) => {
    const payload = {
      name: values?.cName ? values?.cName : "",
      phone: values?.phoneNumber ? values?.phoneNumber : "",
      email: values?.email ? values?.email : "",
      streetAddress: values?.streetAddress,
      unitNumber: values?.unitNumber,
      city: values?.city,
      state: values?.state,
      zip: values?.zipCode,
    };

    const apiResponse = await mutateAsyncCreateCustomer(payload)
      .then((response) => {
        if (response?.customerData) {
          actions?.setFieldValue("customerData", response?.customerData);
          actions?.setFieldValue("appointmentObj", response?.appointmentObj);
          return response;
        } else {
          actions?.setFieldValue("customerError", response?.message);
          return false;
        }
      })
      .catch((error) => {
        actions?.setFieldValue("customerError", error?.message);
        return false;
      });
    return apiResponse;
  };

  const _handleCreateAddress = async (values, actions) => {
    const payload = {
      street: values?.streetAddress,
      unit: values?.unitNumber,
      city: values?.city,
      state: values?.state,
      zip: values?.zipCode,
      appointmentObj: values?.appointmentObj,
    };

    const apiResponse = await mutateAsyncCreateAddress(payload)
      .then((response) => {
        console.log(response, "response");
        if (response?.customerData) {
          //to-do
          actions?.setFieldValue("addressId", 68294284);
          return response;
        } else {
          //to-do
          actions?.setFieldValue("addressId", 68294284);
          actions?.setFieldValue("customerError", response?.message);
          return false;
        }
      })
      .catch((error) => {
        //to-do
        actions?.setFieldValue("addressId", 68294284);
        actions?.setFieldValue("customerError", error?.message);
        return false;
      });
    return apiResponse;
  };

  /**
   *
   * @param {*} values
   * @param {*} actions
   */
  async function _submitForm(values, actions) {
    console.log(values, "values");
    const payload = {
      ...values?.appointmentObj,
      ...values?.appointmentTime,
      questions: values?.selectedQuestionsData,
      date: values?.appointmentDate,
      phone:
        values?.customerType === "existingCustomer"
          ? values?.accountPhoneNumber
          : values?.phoneNumber,
    };

    await mutateAsyncCreateAppointement(payload);
    actions.setSubmitting(true);
    _handleNext(values, actions);
    console.log(payload, "create appointment payload");
  }

  /**
   *
   * @param {*} values
   * @param {*} actions
   */
  function _handleSubmit(values, actions) {
    if (isLastStep) {
      _submitForm(values, actions);
    } else {
      _handleNext(values, actions);
      actions.setTouched({});
      actions.setSubmitting(false);
    }
  }

  function _handleNext(values, actions) {
    switch (activeStep) {
      case 0:
        return _handleClientNext(values, actions);
      case 1:
        return _handleProblemNext(values);
      case 2:
        return _handleDescriptionNext(values);
      case 3:
        return setActiveStep(activeStep + 1);
      case 4:
        return setActiveStep(activeStep + 1);
      default:
        return;
    }
  }

  const _handleProblemNext = (values) => {
    if (isProblemLastStep) {
      setActiveStep(activeStep + 1);
    } else {
      setProblemActiveStep(problemActiveStep + 1);
    }
  };

  const _handleDescriptionSteps = (questionsData) => {
    if (questionsData?.length === 1) {
      const descriptionStepsList = [
        "QuestionStepOne",
        "Diagnostic Fee",
        "Additional Info",
      ];
      setDescriptionSteps(descriptionStepsList);
    } else if (questionsData?.length === 2) {
      const descriptionStepsList = [
        "QuestionStepOne",
        "QuestionStepTwo",
        "Diagnostic Fee",
        "Additional Info",
      ];
      setDescriptionSteps(descriptionStepsList);
    } else if (questionsData?.length === 3) {
      const descriptionStepsList = [
        "QuestionStepOne",
        "QuestionStepTwo",
        "QuestionStepThree",
        "Diagnostic Fee",
        "Additional Info",
      ];
      setDescriptionSteps(descriptionStepsList);
    } else {
      setDescriptionSteps(["Diagnostic Fee", "Additional Info"]);
    }
  };

  const _handleDescriptionNext = (values) => {
    if (isDescriptionLastStep) {
      fetchAvailableSlots(values);
      setActiveStep(activeStep + 1);
    } else {
      setDescriptionActiveStep(descriptionActiveStep + 1);
    }
  };

  const _handleClientNext = async (values, actions) => {
    if (isClientLastStep) {
      if (values?.customerType === "newCustomer") {
        const customerResp = await _handleCreateCustomer(values, actions);
        if (customerResp?.customerData && customerResp?.appointmentObj) {
          setActiveStep(activeStep + 1);
        }
      } else {
        if (
          values?.customerType === "existingCustomer" &&
          values?.isAddNewAddress === true
        ) {
          await _handleCreateAddress(values, actions);
        }
        setActiveStep(activeStep + 1);
      }
    } else {
      setClientActiveStep(clientActiveStep + 1);
    }
  };

  function _handleBack() {
    switch (activeStep) {
      case 0:
        return _handleClientBack();
      case 1:
        return _handleProblemBack();
      case 2:
        return _handleDescriptionBack();
      case 3:
        return setActiveStep(activeStep - 1);
      case 4:
        return setActiveStep(activeStep - 1);
      default:
        return;
    }
  }

  const _handleClientBack = () => {
    if (clientActiveStep !== 0) {
      setClientActiveStep(clientActiveStep - 1);
    }
  };

  const _handleProblemBack = () => {
    if (problemActiveStep === 0) {
      setActiveStep(activeStep - 1);
    } else {
      setProblemActiveStep(problemActiveStep - 1);
    }
  };

  const _handleDescriptionBack = () => {
    if (descriptionActiveStep === 0) {
      setActiveStep(activeStep - 1);
    } else {
      setDescriptionActiveStep(descriptionActiveStep - 1);
    }
  };

  function _renderStepContent(step) {
    switch (step) {
      case 0:
        return (
          <Client
            clientFormField={clientFormField}
            setClientFormField={setClientFormField}
            setCurrentValidationSchema={setCurrentValidationSchema}
            clientActiveStep={clientActiveStep}
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
            setNextHide={setNextHide}
          />
        );

      case 1:
        return (
          <Problem
            problemActiveStep={problemActiveStep}
            setProblemActiveStep={setProblemActiveStep}
            _handleDescriptionSteps={_handleDescriptionSteps}
            _handleNext={_handleNext}
            _handleProblemBack={_handleProblemBack}
            setIsNextdisabled={setIsNextdisabled}
            setActiveStepColor={setActiveStepColor}
          />
        );
      case 2:
        return (
          <Description
            descriptionActiveStep={descriptionActiveStep}
            _handleNext={_handleNext}
            setNextHide={setNextHide}
            setIsNextdisabled={setIsNextdisabled}
            setActiveStepColor={setActiveStepColor}
            _handleDescriptionSteps={_handleDescriptionSteps}
          />
        );
      case 3:
        return (
          <Appointment
            availableSlots={availableSlots}
            availableDates={availableDates}
            appointmentObj={appointmentObj}
            setIsLoading={setIsLoading}
            setIsNextdisabled={setIsNextdisabled}
            IsAvialableSlotsCompleted={IsAvialableSlotsCompleted}
          />
        );
      case 4:
        return <Confirm />;
      default:
        return <Thanks setActiveStepColor={setActiveStepColor} />;
    }
  }

  return (
    <React.Fragment>
      <Box component="div" className={classes.boxWrapper}>
        <Box
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            height: "40px",
            position: "relative",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.05)",
            backgroundColor: "#fff",
          }}
        >
          <Typography
            style={{
              color: "black",
              padding: "13px",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontWeight: "600",
              fontSize: "12px",
              lineHeight: "16px",
              letterSpacing: "0.1em",
              textTransform: "upperCase",
            }}
          >
            CREATE APPOINTMENT
          </Typography>
          <Box
            style={{
              position: "absolute",
              width: "20px",
              height: "20px",
              right: "10px",
              top: "calc(50% - 20px/2)",
              fontWeight: "300",
              fontSize: "20px",
              lineHeight: "20px",
              display: "flex",
              alignItems: "center",
              textAlign: "right",
            }}
          >
            <SvgIcon component={CrossIcon} />
          </Box>
        </Box>

        <>
          <Formik
            initialValues={appointementInitialValues}
            validationSchema={currentValidationSchema}
            onSubmit={_handleSubmit}
          >
            {({ isSubmitting, isValid, values }) => (
              <>
                {isSchedulerCompleted ? (
                  <>
                    {schedulerData?.hasOwnProperty("offeredJobs") ? (
                      <>
                        <Stepper
                          activeStep={activeStep}
                          className={classes.stepsProgessBar}
                        >
                          {steps.map((label) => (
                            <Step key={label} className={classes.stepWrap}>
                              <StepLabel>{label}</StepLabel>
                            </Step>
                          ))}
                        </Stepper>
                        <Box className={classes.h100}>
                          <Form
                            id={formId}
                            className={
                              activeStep === 1 && problemActiveStep === 1
                                ? classes.boxWrapper
                                : "justifyBetween " + classes.boxWrapper
                            }
                          >
                            {_renderStepContent(activeStep)}
                            <Backdrop
                              style={{
                                zIndex: 99,
                                position: "absolute",
                                background: "#4A4753",
                                color: "#007BFF",
                                opacity: "0.7",
                              }}
                              open={isLoading}
                            >
                              <CircularProgress
                                style={{ color: schedulerData?.colorCode }}
                              />
                            </Backdrop>
                          </Form>
                        </Box>
                        {activeStep !== 1 &&
                          activeStep !== steps.length &&
                          clientActiveStep !== 0 && (
                            <ButtonAppBar
                              nextHide={nextHide}
                              _handleBack={_handleBack}
                              //  isSubmitting={isSubmitting}
                              isNextdisabled={isNextdisabled}
                              isLastStep={isLastStep}
                              // isValid={isValid}
                            />
                          )}
                      </>
                    ) : (
                      <Box>
                        <Typography
                          variant="h6"
                          color="error"
                          className={classes.errorMessage}
                        >
                          Something went wrong! Please check your network
                          connection or Reload again.
                        </Typography>
                      </Box>
                    )}
                  </>
                ) : (
                  <Backdrop
                    style={{
                      zIndex: 99,
                      position: "absolute",
                      background: "#4A4753",
                      color: "#007BFF",
                      opacity: "0.7",
                    }}
                    open={true}
                  >
                    <CircularProgress
                      style={{ color: schedulerData?.colorCode }}
                    />
                  </Backdrop>
                )}
              </>
            )}
          </Formik>
        </>
      </Box>
    </React.Fragment>
  );
}
