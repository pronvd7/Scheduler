import React, { useContext } from "react";
import Box from "@mui/material/Box";
import { makeStyles } from "@material-ui/core/styles";
import { Button, CircularProgress } from "@material-ui/core";
import DataSaverOffOutlined from "@mui/icons-material/DataSaverOffOutlined";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowLeftLong,
  faCheck,
  faArrowRightLong,
} from "@fortawesome/free-solid-svg-icons";
import { useFormikContext } from "formik";
import { SchedulerContext } from "../../context/schedulerContext";
import appointmentFormStyle from "../AppointmentForm/styles";

export default function ButtonAppBar(props) {
  const {
    nextHide,
    _handleBack,
    // isSubmitting,
    isNextdisabled,
    isLastStep,
    // isValid,
  } = props;
  const classes = appointmentFormStyle();
  const { schedulerData } = useContext(SchedulerContext);

  const { submitForm, isSubmitting, isValid } = useFormikContext();

  const handleOutsideSubmit = () => {
    submitForm();
  };

  return (
    <Box
      component="footer"
      sx={{
        width: "100%",
      }}
    >
      <Box
        sx={{
          background: "#F2F5FB",
          color: "#1F2327",
          alignItems: "center",
          display: "flex",
          justifyContent: ["space-between"],
          padding: ".5rem",
          gap: ".5rem ",
        }}
      >
        <Button
          startIcon={<FontAwesomeIcon icon={faArrowLeftLong} />}
          className={`whiteBtn ${classes.themeBtn}`}
          onClick={_handleBack}
        >
          <span style={{ fontSize: "0.875rem", fontWeight: "600" }}>Back</span>
        </Button>
        {!nextHide ? (
          <Button
            style={{
              background: schedulerData?.colorCode, //"#007BFF",
              border: `1px solid ${schedulerData?.colorCode}`,
            }}
            className={`primary ${classes.themeBtn}`}
            startIcon={
              isLastStep ? (
                <FontAwesomeIcon icon={faCheck} />
              ) : (
                <FontAwesomeIcon icon={faArrowRightLong} size="sm" />
              )
            }
            disabled={isNextdisabled || isSubmitting || !isValid}
            type="submit"
            onClick={handleOutsideSubmit}
          >
            {isLastStep ? "Confirm appointment" : "Next"}
          </Button>
        ) : (
          ""
        )}
      </Box>
    </Box>
  );
}
