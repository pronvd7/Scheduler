import React from "react";
import { Stepper } from "@mui/material";

const CustomStyledButton = ({ buttonColor, ...props }) => {
  return (
    <Stepper
      variant="contained"
      sx={{
        backgroundColor: props.buttonColor || "orange",
        color: "white",
        "&:hover": {
          backgroundColor: props.hoverColor || "darkorange",
        },
      }}
      {...props}
    >
      {buttonText}
    </Stepper>
  );
};

export default CustomStyledButton;
