import React from "react";
import { Grid, Typography } from "@material-ui/core";
import TodayIcon from "@mui/icons-material/Today";
import { Box, Stack } from "@mui/material";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import { styled } from "@mui/material/styles";
//import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
//import LocalPhoneOutlinedIcon from "@mui/icons-material/LocalPhoneOutlined";
import { PhoneIcons, Location } from "../../Icons";
import { SvgIcon } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import { useState } from "react";
import { CheckboxField } from "../../FormFields";
import appointmentFormStyle from "../styles";
import { useFormikContext } from "formik";
import moment from "moment";

export default function Confirm() {
  const { values } = useFormikContext();
  const {
    formattedAddress,
    appointmentDate,
    appointmentTime,
    accountPhoneNumber,
    phoneNumber,
    customerType,
  } = values;
  const classes = appointmentFormStyle();

  const startTime = moment(appointmentTime?.start, "HH:mm").format("h:mm A");
  const endTime = moment(appointmentTime?.end, "HH:mm").format("h:mm A");

  return (
    <React.Fragment>
      <div className={classes.formDivWithHeight}>
        <Box component="div">
          <Typography
            variant="h6"
            className={classes.headingSix}
            style={{ marginBottom: "1.875rem" }}
          >
            Please review and confirm appointment
            <hr
              className={classes.titleHr}
              style={{
                marginLeft: "0px",
              }}
            ></hr>
          </Typography>
        </Box>
        <Box sx={{ width: "100%" }}>
          <Stack spacing={2}>
            <Box className={classes.confirmBoxInfo} component="div">
              <TodayIcon style={{ color: "#007BFF" }} />
              <span>{moment(appointmentDate).format("MMMM D, YYYY")}</span>
            </Box>
            <Box component="div" className={classes.confirmBoxInfo}>
              <AccessTimeIcon style={{ color: "#007BFF" }} />
              <span>{`${startTime} - ${endTime}`}</span>
            </Box>
            {formattedAddress !== "" && (
              <Box component="div" className={classes.confirmBoxInfo}>
                <SvgIcon component={Location} />
                <span>{formattedAddress}</span>
              </Box>
            )}
            <Box component="div" className={classes.confirmBoxInfo}>
              <SvgIcon component={PhoneIcons} />
              <span>
                {customerType === "existingCustomer"
                  ? accountPhoneNumber
                  : phoneNumber}
              </span>
            </Box>
          </Stack>
        </Box>
        <Grid>
          <Box component="div" sx={{ paddingTop: "1.5rem" }}>
            <div className="childField">
              <CheckboxField
                className={[classes.checkBoxClass, classes.checkBoxConfirm]}
                name="termConditions"
                label={
                  <>
                    <span
                      style={{
                        fontFamily: "Poppins",
                        fontStyle: "normal",
                        fontWeight: "400",
                        fontSize: "16px",
                        lineHeight: "32px",
                        color: "#1F2327",
                      }}
                    >
                      I accept the{" "}
                      <span style={{ color: "#007BFF" }}>
                        terms and conditions
                      </span>
                    </span>
                  </>
                }
              />
            </div>
            {/*   <Checkbox
              className={classes.checkbox}
              defaultChecked
              size="small"
              sx={{ padding: "0 1rem 0 0" }}
            />
            <span
              style={{
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontWeight: "400",
                fontSize: "16px",
                lineHeight: "32px",
                color: "#1F2327",
              }}
            >
              I accept the{" "}
              <span style={{ color: "#007BFF" }}>terms and conditions</span>
            </span> */}
          </Box>
        </Grid>
        <Typography
          variant="p"
          style={{
            paddingTop: "1.5rem",
            display: "block",
            fontSize: ".938rem",
            lineHeight: "1.5rem",
            color: "#6C6F7C",
            fontStyle: "italic",
          }}
        >
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
          interdum, diam vel fermentum posuere, enim massa.
        </Typography>
      </div>
    </React.Fragment>
  );
}
