import React, { useEffect, useState } from "react";
import { Typography } from "@material-ui/core";
import { Box } from "@mui/material";
/// import { InputField, DatePickerField } from '../../FormFields';
import Radio from "@mui/joy/Radio";
import RadioGroup from "@mui/joy/RadioGroup";
import Sheet from "@mui/joy/Sheet";
import { useFormikContext } from "formik";
import appointmentFormStyle from "../styles";

export default function MaintenanceQuestion(props) {
  const { setIsNextdisabled, _handleDescriptionSteps, questionsData } = props;
  const classes = appointmentFormStyle();
  const { setFieldValue, values } = useFormikContext();
  const {
    selectedData,
    selectedQuestionsData,
    tempData,
    serviceCategory,
  } = values;

  const [isSystemWorkingData, setIsSystemWorkingData] = useState(
    tempData?.[`${serviceCategory}-isSystemWorkingData`]
      ? tempData?.[`${serviceCategory}-isSystemWorkingData`]
      : []
  );

  useEffect(() => {
    setIsNextdisabled(false);
  }, []);

  useEffect(() => {
    if (
      tempData?.[`${serviceCategory}-isSystemWorkingData`] !== undefined &&
      tempData?.[`${serviceCategory}-isSystemWorkingData`]?.length > 0
    ) {
      setIsSystemWorkingData(
        tempData?.[`${serviceCategory}-isSystemWorkingData`]
      );
    }
  }, []);

  return (
    <React.Fragment>
      <div className={classes.formDivWithHeight}>
        <Box component="p" variant="p" className={classes.textBreadcrumb}>
          {`${selectedData?.service} - ${selectedData?.serviceType} - ${selectedData?.serviceCategory} `}
        </Box>
        {React.Children.toArray(
          questionsData?.map((question) => (
            <>
              <Typography variant="h6" className={classes.headingSix}>
                Is your current system working properly?
                <hr
                  className={classes.titleHr}
                  style={{
                    marginLeft: "0px",
                  }}
                ></hr>
              </Typography>
              <RadioGroup
                name={`${serviceCategory}-${question?.name}`}
                className={`threeColumns  ${classes.radioBox}`}
                aria-labelledby="storage-label"
                defaultValue={
                  values?.tempData?.[`${serviceCategory}-${question?.name}`]
                }
                size="lg"
                // sx={{ paddingTop: '1rem' }}
              >
                {question?.answers.map((answer) => (
                  <Sheet
                    className={classes.sheetInput}
                    key={answer?.id}
                    sx={{
                      // borderRadius: "md",
                      // boxShadow: "sm",
                      bgcolor: "background.body",
                    }}
                  >
                    <Radio
                      className={classes.sheetRadioOpt}
                      label={answer?.label}
                      overlay
                      disableIcon
                      value={answer?.value}
                      onChange={() => {
                        setFieldValue("selectedData", {
                          ...selectedData,
                        });

                        setFieldValue("selectedQuestionsData", {
                          ...selectedQuestionsData,
                          [question?.question]: answer?.value,
                        });

                        setFieldValue("tempData", {
                          ...tempData,
                          [`${serviceCategory}-${question?.name}`]: answer?.value,
                          [`${serviceCategory}-${question?.name}Data`]: answer?.data,
                        });

                        setIsSystemWorkingData(answer?.data);

                        //set next screen questions based on previous answers
                        if (
                          answer?.subQuestionData !== undefined &&
                          answer?.subQuestionData?.length > 0
                        ) {
                          setFieldValue(
                            "subQuestionData",
                            answer?.subQuestionData
                          );
                          _handleDescriptionSteps(answer?.subQuestionData);
                        }
                      }}
                      slotProps={{
                        label: ({ checked }) => ({
                          sx: {
                            // fontWeight: "lg",
                            // fontSize: "md",
                            color: checked ? "text.primary" : "text.secondary",
                          },
                        }),
                        action: ({ checked }) => ({
                          sx: (theme) => ({
                            ...(checked && {
                              "--variant-borderWidth": "2px",
                              "&&": {
                                // && to increase the specificity to win the base :hover styles
                                borderColor: theme.vars.palette.primary[500],
                              },
                            }),
                          }),
                        }),
                      }}
                    />
                  </Sheet>
                ))}
              </RadioGroup>
            </>
          ))
        )}

        <>
          {isSystemWorkingData?.length > 0 &&
            React.Children.toArray(
              isSystemWorkingData?.map((question) => (
                <>
                  <Typography variant="h6" className={classes.headingSix}>
                    {question?.question}
                    <hr
                      className={classes.titleHr}
                      style={{
                        marginLeft: "0px",
                      }}
                    ></hr>
                  </Typography>
                  <RadioGroup
                    className={`threeColumns  ${classes.radioBox}`}
                    name={question?.name}
                    defaultValue={
                      values?.tempData?.[`${serviceCategory}-${question?.name}`]
                    }
                    aria-labelledby="storage-label"
                    size="lg"
                    // sx={{ paddingTop: '1rem' }}
                  >
                    {question?.answers.map((answer) => (
                      <Sheet
                        className={classes.sheetInput}
                        key={answer?.id}
                        sx={{
                          // borderRadius: "md",
                          // boxShadow: "sm",
                          bgcolor: "background.body",
                        }}
                      >
                        <Radio
                          className={classes.sheetRadioOpt}
                          label={answer?.label}
                          overlay
                          disableIcon
                          value={answer?.value}
                          onChange={() => {
                            if (answer?.jobType !== undefined) {
                              setFieldValue("selectedData", {
                                ...selectedData,
                                jobType: answer?.jobType,
                              });
                            } else if (answer?.subJobType !== undefined) {
                              setFieldValue("selectedData", {
                                ...selectedData,
                                subJobType: answer?.subJobType,
                              });
                            }

                            setFieldValue("selectedQuestionsData", {
                              ...selectedQuestionsData,
                              [question?.question]: answer?.value,
                            });

                            setFieldValue("tempData", {
                              ...tempData,
                              [`${serviceCategory}-${question?.name}`]: answer?.value,
                            });
                          }}
                          slotProps={{
                            label: ({ checked }) => ({
                              sx: {
                                // fontWeight: "lg",
                                // fontSize: "md",
                                color: checked
                                  ? "text.primary"
                                  : "text.secondary",
                              },
                            }),
                            action: ({ checked }) => ({
                              sx: (theme) => ({
                                ...(checked && {
                                  "--variant-borderWidth": "2px",
                                  "&&": {
                                    // && to increase the specificity to win the base :hover styles
                                    borderColor:
                                      theme.vars.palette.primary[500],
                                  },
                                }),
                              }),
                            }),
                          }}
                        />
                      </Sheet>
                    ))}
                  </RadioGroup>
                </>
              ))
            )}
        </>
      </div>
    </React.Fragment>
  );
}
