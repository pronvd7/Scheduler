import React, { useEffect, useState } from "react";
import { Typography } from "@material-ui/core";
import { Box } from "@mui/material";
/// import { InputField, DatePickerField } from '../../FormFields';
import Radio from "@mui/joy/Radio";
import RadioGroup from "@mui/joy/RadioGroup";
import Sheet from "@mui/joy/Sheet";
import { useFormikContext } from "formik";
import appointmentFormStyle from "../styles";

export default function QuestionsStep(props) {
  const { setIsNextdisabled, questionsData } = props;
  const classes = appointmentFormStyle();
  const { setFieldValue, values } = useFormikContext();
  const {
    selectedData,
    selectedQuestionsData,
    tempData,
    serviceCategory,
  } = values;

  const [hiddenQuestionData, setHiddenQuestionData] = useState(
    tempData?.[`${serviceCategory}-hiddenQuestionData`]
      ? tempData?.[`${serviceCategory}-hiddenQuestionData`]
      : []
  );

  useEffect(() => {
    setIsNextdisabled(false);
  }, []);

  useEffect(() => {
    if (
      tempData?.[`${serviceCategory}-hiddenQuestionData`] !== undefined &&
      tempData?.[`${serviceCategory}-hiddenQuestionData`]?.length > 0
    ) {
      setHiddenQuestionData(
        tempData?.[`${serviceCategory}-hiddenQuestionData`]
      );
    }
  }, []);

  const _handleChange = (answer, question) => {
    setFieldValue("selectedQuestionsData", {
      ...selectedQuestionsData,
      [question?.question]: answer?.value,
    });

    if (answer?.jobType !== undefined) {
      setFieldValue("selectedData", {
        ...selectedData,
        jobType: selectedData?.subJobType
          ? `${answer?.jobType}: ${selectedData?.subJobType}`
          : answer?.jobType,
      });
    } else if (answer?.subJobType !== undefined) {
      setFieldValue("selectedData", {
        ...selectedData,
        subJobType: answer?.subJobType,
      });
    } else {
      setFieldValue("selectedData", {
        ...selectedData,
      });
    }
  };

  return (
    <React.Fragment>
      <div className={classes.formDivWithHeight}>
        <Box component="p" variant="p" className={classes.textBreadcrumb}>
          {`${selectedData?.service} - ${selectedData?.serviceType} - ${selectedData?.serviceCategory} `}
        </Box>
        {React.Children.toArray(
          questionsData?.map((question) => (
            <>
              <Typography variant="h6" className={classes.headingSix}>
                {question?.question}
                <hr
                  className={classes.titleHr}
                  style={{
                    marginLeft: "0px",
                  }}
                ></hr>
              </Typography>
              <RadioGroup
                name={`${serviceCategory}-${question?.name}`}
                className={`threeColumns  ${classes.radioBox}`}
                aria-labelledby="storage-label"
                defaultValue={
                  values?.tempData?.[`${serviceCategory}-${question?.name}`]
                }
                size="lg"
                // sx={{ paddingTop: '1rem' }}
              >
                {question?.answers.map((answer) => (
                  <Sheet
                    className={classes.sheetInput}
                    key={answer?.id}
                    sx={{
                      // borderRadius: "md",
                      // boxShadow: "sm",
                      bgcolor: "background.body",
                    }}
                  >
                    <Radio
                      className={classes.sheetRadioOpt}
                      label={answer?.label}
                      overlay
                      disableIcon
                      value={answer?.value}
                      onChange={() => {
                        _handleChange(answer, question);
                        if (
                          answer?.hiddenQuestionData !== undefined &&
                          answer?.hiddenQuestionData.length > 0
                        ) {
                          setHiddenQuestionData(answer?.hiddenQuestionData);
                          setFieldValue("tempData", {
                            ...tempData,
                            [`${serviceCategory}-${question?.name}`]: answer?.value,
                            [`${serviceCategory}-hiddenQuestionData`]: answer?.hiddenQuestionData,
                          });
                        } else {
                          setHiddenQuestionData([]);
                          setFieldValue("tempData", {
                            ...tempData,
                            [`${serviceCategory}-${question?.name}`]: answer?.value,
                            [`${serviceCategory}-hiddenQuestionData`]: [],
                          });
                        }
                      }}
                      slotProps={{
                        label: ({ checked }) => ({
                          sx: {
                            // fontWeight: "lg",
                            // fontSize: "md",
                            color: checked ? "text.primary" : "text.secondary",
                          },
                        }),
                        action: ({ checked }) => ({
                          sx: (theme) => ({
                            ...(checked && {
                              "--variant-borderWidth": "2px",
                              "&&": {
                                // && to increase the specificity to win the base :hover styles
                                borderColor: theme.vars.palette.primary[500],
                              },
                            }),
                          }),
                        }),
                      }}
                    />
                  </Sheet>
                ))}
              </RadioGroup>
            </>
          ))
        )}
        <>
          {hiddenQuestionData?.length > 0 &&
            React.Children.toArray(
              hiddenQuestionData?.map((question) => (
                <>
                  <Typography variant="h6" className={classes.headingSix}>
                    {question?.question}
                    <hr
                      className={classes.titleHr}
                      style={{
                        marginLeft: "0px",
                      }}
                    ></hr>
                  </Typography>
                  <RadioGroup
                    className={`threeColumns  ${classes.radioBox}`}
                    name={question?.name}
                    defaultValue={
                      values?.tempData?.[`${serviceCategory}-${question?.name}`]
                    }
                    aria-labelledby="storage-label"
                    size="lg"
                    // sx={{ paddingTop: '1rem' }}
                  >
                    {question?.answers.map((answer) => (
                      <Sheet
                        className={classes.sheetInput}
                        key={answer?.id}
                        sx={{
                          // borderRadius: "md",
                          // boxShadow: "sm",
                          bgcolor: "background.body",
                        }}
                      >
                        <Radio
                          className={classes.sheetRadioOpt}
                          label={answer?.label}
                          overlay
                          disableIcon
                          value={answer?.value}
                          onChange={() => {
                            if (answer?.jobType !== undefined) {
                              setFieldValue("selectedData", {
                                ...selectedData,
                                jobType: selectedData?.subJobType
                                  ? `${answer?.jobType}: ${selectedData?.subJobType}`
                                  : answer?.jobType,
                              });
                            } else if (answer?.subJobType !== undefined) {
                              setFieldValue("selectedData", {
                                ...selectedData,
                                subJobType: answer?.subJobType,
                              });
                            }

                            setFieldValue("selectedQuestionsData", {
                              ...selectedQuestionsData,
                              [question?.question]: answer?.value,
                            });

                            setFieldValue("tempData", {
                              ...tempData,
                              [`${serviceCategory}-${question?.name}`]: answer?.value,
                            });
                          }}
                          slotProps={{
                            label: ({ checked }) => ({
                              sx: {
                                // fontWeight: "lg",
                                // fontSize: "md",
                                color: checked
                                  ? "text.primary"
                                  : "text.secondary",
                              },
                            }),
                            action: ({ checked }) => ({
                              sx: (theme) => ({
                                ...(checked && {
                                  "--variant-borderWidth": "2px",
                                  "&&": {
                                    // && to increase the specificity to win the base :hover styles
                                    borderColor:
                                      theme.vars.palette.primary[500],
                                  },
                                }),
                              }),
                            }),
                          }}
                        />
                      </Sheet>
                    ))}
                  </RadioGroup>
                </>
              ))
            )}
        </>
      </div>
    </React.Fragment>
  );
}
