import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import { Typography } from "@material-ui/core";
import TextField from "@mui/material/TextField";
import { useFormikContext } from "formik";
import appointmentFormStyle from "../styles";

const AdditonalInfoStep = (props) => {
  const classes = appointmentFormStyle();
  const { setIsNextdisabled } = props;
  const { setFieldValue, values } = useFormikContext();
  const { selectedData } = values;
  const [AdditionalInfo, setAdditionalInfo] = useState(values?.additionalInfo);

  const handleChange = (event) => {
    setAdditionalInfo(event.target.value);
    setFieldValue("additionalInfo", event.target.value);
  };

  /*useEffect(() => {
    if (AdditionalInfo === "") {
      setIsNextdisabled(true);
    } else {
      setIsNextdisabled(false);
    }
  }, [AdditionalInfo]); */

  return (
    <Box component="div" className={classes.formDivWithHeight}>
      <Box component="p" variant="p" className={classes.textBreadcrumb}>
        {`${selectedData?.service} - ${selectedData?.serviceType} - ${selectedData?.serviceCategory} `}
      </Box>
      <Typography variant="h6" gutterBottom className={classes.headingSix}>
        Additional information
        <hr
          className={classes.titleHr}
          style={{
            marginLeft: "0px",
          }}
        ></hr>
      </Typography>

      <Box
        component="div"
        className="text-para"
        sx={{ width: "100%", margin: "auto" }}
      >
        <Box
          component="p"
          variant="p"
          style={{
            color: "#4D4F59",
            fontSize: "1rem",
            lineHeight: "2rem",
            marginBottom: "0",
          }}
        >
          Please share any information you'd like about your equipment, project,
          or issues you are facing.
        </Box>
      </Box>
      <Box
        component="div"
        className="text-area"
        sx={{ paddingTop: "2rem", margin: "auto" }}
      >
        <TextField
          name="AdditionalInfo"
          value={AdditionalInfo}
          onChange={handleChange}
          style={{ width: "100%" }}
          id="outlined-basic"
          label="Issue description"
          multiline
          rows={8}
          variant="outlined"
          className={classes.textFieldDiv}
          inputProps={{
            style: {
              fontSize: "1rem",
              fontFamily: "Poppins",
              color: "#1F2327",
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default AdditonalInfoStep;
