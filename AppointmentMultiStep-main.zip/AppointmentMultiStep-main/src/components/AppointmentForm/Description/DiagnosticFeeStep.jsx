import React, { useEffect, useState, useContext } from "react";
import { Typography } from "@material-ui/core";
import { Box } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import appointmentFormStyle from "../styles";
import { useFormikContext } from "formik";
import { CheckboxField } from "../../FormFields";
import { SchedulerContext } from "../../../context/schedulerContext";

const DiagnosticFeeStep = (props) => {
  const classes = appointmentFormStyle();
  const { setIsNextdisabled } = props;
  const { setFieldValue, values } = useFormikContext();
  const { schedulerData } = useContext(SchedulerContext);
  const { selectedData } = values;
  const [isChecked, setIschecked] = useState(values?.diagnosticFee);

  useEffect(() => {
    if (isChecked) {
      setIsNextdisabled(false);
    } else {
      setIsNextdisabled(true);
    }
    setFieldValue("diagnosticFee", isChecked);
  }, [isChecked]);

  useEffect(() => {
    console.log(values, "values");
  }, [values]);

  return (
    <div className={classes.formDivWithHeight}>
      <Box component="p" variant="p" className={classes.textBreadcrumb}>
        {`${selectedData?.service} - ${selectedData?.serviceType} - ${selectedData?.serviceCategory} `}
      </Box>
      <Typography variant="h6" className={classes.headingSix}>
        This visit requires a diagnostic fee of{" "}
        {schedulerData?.dispatchFee ? `$${schedulerData?.dispatchFee}` : ""}
        <hr
          className={classes.titleHr}
          style={{
            marginLeft: "0px",
          }}
        ></hr>
      </Typography>

      <div style={{ width: "100%", margin: "auto", marginTop: "1rem" }}>
        <Box
          component="p"
          variant="p"
          style={{
            color: "#4D4F59",
            fontWeight: "normal",
            fontSize: "1rem",
            lineHeight: "2rem",
          }}
        >
          Pellentesque bibendum sapien at dui accumsan, condimentum cursus
          turpis porta. Suspendisse euismod risus nibh, sit amet tristique elit
          posuere in. Sed ut lacinia nisl. Sed non leo auctor est porta
          fermentum sed eu erat.
        </Box>
      </div>
      <Box
        component="div"
        sx={{
          display: "flex",
          alignItems: "flex-start",
          flexDirection: "row",
          paddingTop: "1.375rem",
        }}
      >
        <CheckboxField
          className={classes.checkBoxClass}
          defaultChecked={isChecked}
          onChange={() => setIschecked(!isChecked)}
          name="DiagnosticFee"
          label={`I understand there is a ${
            schedulerData?.dispatchFee ? `$${schedulerData?.dispatchFee}` : ""
          } diagnostic cost`}
        />
      </Box>
    </div>
  );
};
export default DiagnosticFeeStep;
