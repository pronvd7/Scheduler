import React, { useEffect, useState } from "react";
import { useFormikContext } from "formik";
import QuestionsStep from "./QuestionsStep";
import DiagnosticFeeStep from "./DiagnosticFeeStep";
import AdditionalInfoStep from "./AdditionalInfoStep";
import MaintenanceQuestion from "./MaintenanceQuestion";

export default function Description(props) {
  const {
    _handleNext,
    descriptionActiveStep,
    setIsNextdisabled,
    setNextHide,
    setActiveStepColor,
    _handleDescriptionSteps,
  } = props;

  const { values } = useFormikContext();
  const { questionsData, subQuestionData, selectedData } = values;

  /* useEffect(() => {
    setNextHide(false);
  }, []); */

  useEffect(() => {
    setActiveStepColor("#FFFFFF");
    //setDescriptionActiveStep(1);
  }, []);

  const _handleCaseForZero = (step) => {
    switch (step) {
      case 0:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 1:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  const _handleCaseForOne = (step) => {
    switch (step) {
      case 0:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={questionsData[step]}
          />
        );
      case 1:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 2:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  const _handleCaseForTwo = (step) => {
    switch (step) {
      case 0:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={questionsData[step]}
          />
        );
      case 1:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={questionsData[step]}
          />
        );
      case 2:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 3:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  const _handleCaseForThree = (step) => {
    switch (step) {
      case 0:
        return (
          <QuestionsStep
            questionsData={questionsData[step]}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      case 1:
        return (
          <QuestionsStep
            questionsData={questionsData[step]}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      case 2:
        return (
          <QuestionsStep
            questionsData={questionsData[step]}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      case 3:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 4:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  const _handleMaintenanceTwoSteps = (step) => {
    switch (step) {
      case 0:
        return (
          <MaintenanceQuestion
            setIsNextdisabled={setIsNextdisabled}
            questionsData={questionsData[step]}
            _handleDescriptionSteps={_handleDescriptionSteps}
          />
        );
      case 1:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={subQuestionData[step]} // we are not including MaintenanceQuestion step questions data in that array that's why we did -1
          />
        );
      case 2:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 3:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  const _handleMaintenanceThreeSteps = (step) => {
    switch (step) {
      case 0:
        return (
          <MaintenanceQuestion
            setIsNextdisabled={setIsNextdisabled}
            questionsData={questionsData[step]}
            _handleDescriptionSteps={_handleDescriptionSteps}
          />
        );
      case 1:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={subQuestionData[step]} // we are not including MaintenanceQuestion step questions data in that array that's why we did -1
          />
        );
      case 2:
        return (
          <QuestionsStep
            setIsNextdisabled={setIsNextdisabled}
            questionsData={subQuestionData[step]} // we are not including MaintenanceQuestion step questions data in that array that's why we did -1
          />
        );
      case 3:
        return <DiagnosticFeeStep setIsNextdisabled={setIsNextdisabled} />;
      case 4:
        return (
          <AdditionalInfoStep
            _handleNext={_handleNext}
            setIsNextdisabled={setIsNextdisabled}
          />
        );
      default:
        return <div>Not Found</div>;
    }
  };

  function _renderStepContent(step) {
    if (
      (selectedData?.serviceCategory === "Heating Tune-Up" ||
        selectedData?.serviceCategory === "Cooling Tune-Up") &&
      selectedData?.serviceType === "Maintenance"
    ) {
      if (subQuestionData?.length === 3) {
        return _handleMaintenanceThreeSteps(step);
      } else {
        return _handleMaintenanceTwoSteps(step);
      }
      // handle case if 5th or 6th questions to ask
    } else {
      if (questionsData?.length === 1) {
        return _handleCaseForOne(step); // handle case if 1st or 2nd questions to ask
      } else if (questionsData?.length === 2) {
        return _handleCaseForTwo(step); // handle case if 3rd or 4th questions to ask
      } else if (questionsData?.length === 3) {
        return _handleCaseForThree(step); // handle case if 5th or 6th questions to ask
      } else {
        return _handleCaseForZero(step);
      }
    }
  }

  return (
    <React.Fragment>{_renderStepContent(descriptionActiveStep)}</React.Fragment>
  );
}
