import React, { useEffect } from "react";
import { Button, Typography } from "@material-ui/core";
import appointmentFormStyle from "../styles";
import { ThumbIcon } from "../../Icons";
import { SvgIcon } from "@mui/material";
import { Box } from "@mui/material";
function Thanks(props) {
  const { setActiveStepColor } = props;
  const classes = appointmentFormStyle();
  useEffect(() => {
    setActiveStepColor("#F2F0FA");
  }, []);
  return (
    <React.Fragment>
      <div
        className={
          classes.formDivWithHeight
        } /*</React.Fragment>style={{ backgroundColor: "#F2F0FA", height: "593px" }}*/
      >
        <Typography
          variant="h4"
          className={classes.headingFour}
          sx={{ color: "black" }}
        >
          Thank you, appointment created
          <hr className={classes.titleHr}></hr>
        </Typography>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            padding: "1.5rem",
          }}
        >
          <Button
            className={`whiteBtn btnLarge ${classes.themeBtn}`}
            sx={{ textTransform: "initial" }}
            startIcon={<SvgIcon component={ThumbIcon} />}
          >
            <Box component="div" sx={{ marginLeft: "1rem" }}>
              Ok, great
            </Box>
          </Button>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Thanks;
