import { makeStyles } from "@material-ui/core/styles";
const appointmentFormStyle = makeStyles((theme) => ({
  stepper: {
    padding: theme.spacing(3, 0, 5),
  },
  buttons: {
    display: "flex",
    justifyContent: "flex-end",
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  wrapper: {
    margin: theme.spacing(1),
    position: "relative",
  },
  buttonProgress: {
    position: "absolute",
    top: "50%",
    left: "50%",
  },
  myFormControlLabelRoot: {
    marginLeft: "0px",
    marginRight: "0px",
    "&:hover": {
      background: "#F8FBFD !Important",
      border: "1px solid #007BFF !Important",
      color: "#007BFF !Important",
    },
  },
  formDiv: {
    padding: "1rem 1.5rem  1rem  1.5rem",
    // paddingBottom: "24px"
  },

  radioBox: {
    position: "relative",
    display: "grid !important ",
    gridTemplateColumns: "auto auto auto",
    paddingTop: "1.5rem",
    paddingBottom: "1.5rem",
    "&.twoColumns": {
      gridTemplateColumns: " repeat(2, 1fr)",
      gap: "1.5rem",
    },
    "&.threeColumns": {
      display: "flex!important",
      flexDirection: "row",
      flexWrap: "wrap",
      width: "fit-content",
      gap: "0.625rem",
    },
  },
  sheetInput: {
    "&.MuiSheet-root": {
      padding: "4px 13px",
      width: "fit-content",
      textAlign: "center",
    },
    "& .css-1fjq3ub-JoyRadio-root": {
      fontSize: "1rem",
      lineHeight: "2rem",
      fontFamily: ["Poppins", "sans-serif"].join(","),
    },
    "& .css-l3zqaq-JoyRadio-input": {
      position: "static",
    },
    "& .Joy-checked": {
      fontFamily: ["Poppins", "sans-serif"].join(","),
      borderColor: "#007bff",
      borderWidth: "1px",
      backgroundColor: "#e2f0ff",
      fontSize: "1rem",
      lineHeight: "2rem",
      "--variant-borderWidth": "1px",
    },
    "& .css-1p8kzi6": {
      color: " #007BFF",
    },
    "& .css-146vgrr": {
      fontSize: "16px",
      fontFamily: "Poppins",
      "--Radio-size": "2rem",
    },
    "& .css-v2ra2r-JoyRadio-action": {
      "--variant-borderWidth": "1px",
    },
    "& .css-iqfjqt-JoyRadio-label": {
      color: "#007BFF !important",
    },
  },
  sheetRadioOpt: {
    "& .MuiRadio-action": {
      borderRadius: ".5rem",
    },
  },
  formDivWithHeight: {
    padding: "1rem 1.5rem 1rem 1.5rem",
    height: "auto",
  },
  textFieldDiv: {
    "& div.MuiInputBase-root": {
      fontFamily: ["Poppins", "sans-serif"].join(","),
      // padding: ".5rem 1rem !important",
    },
    "& input:-internal-autofill-selected": {
      WebkitBoxShadow: "0 0 0 100px #fff inset",
    },
    "& .MuiFormLabel-root": {
      // top: '3px',
      fontFamily: ["Poppins", "sans-serif"].join(","),
    },
    "&.MuiAutocomplete-root": {
      "& .MuiOutlinedInput-root": {
        padding: "0 !important",
      },
    },
    "& div.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input": {
      padding: "0.813rem 1rem !important",
    },
    "& .MuiIconButton-root": {
      padding: "0.313rem 0.625rem 0 .25rem",
    },
    "& .css-1d3z3hw-MuiOutlinedInput-notchedOutline": {
      // top: 0,
    },
    // text fields spacing
    "& div.MuiInputBase-root Input.MuiInputBase-input": {
      padding: "14px 14px 12px",
      // padding: "0px !important",
      // height: "2rem",
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: ".625rem",
    },
    "& .MuiIconButton-edgeEnd": {
      marginRight: "0px",
    },
  },

  orDivideSpan: {
    flexGrow: 1,
    borderBottom: `2px solid ${theme.palette.primary.main}`,
    margin: "0 10px",
  },
  flexFieldWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    //gap: "1.5rem",
    flexGrow: "1",
  },
  ButtonAddress: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  flexFieldWrap: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: "1.5rem",
    flexGrow: "1",
    "& .childField": {
      flexGrow: 1,
      width: "100%",
      maxWidth: "100%",
      "& .MuiFormControlLabel-root": {
        gap: "12px",
        marginLeft: "0px",
        marginRight: "50px",
      },
    },
    "& .childLabel": {
      flexGrow: 1,
      width: "100%",
      maxWidth: "100%",
    },
    [theme.breakpoints.up(600)]: {
      "& .childField": {
        maxWidth: "60%",
        width: "auto",
      },
    },
  },
  formTitleTypoGraphy: {
    // padding: "24px",
    paddingBottom: "0px",
    fontWeight: 600,
    fontSize: "1.25rem",
    lineHeight: "1.75rem",
  },
  formTitleHr: {
    height: "3px",
    width: "24px",
    border: "none",
    background: theme.palette.primary.main,
    margin: ".375rem auto 0",
  },
  formTitleDiv: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem 1rem",
    margin: "auto",
    // marginTop: "10px",
    "& .MuiTypography-root": {
      fontFamily: ["Poppins", "sans-serif"].join(","),
    },
  },

  formAccountDiv: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
  },
  formInstructionTypo: {
    fontWeight: "400",
    fontSize: "16px",
    margin: "0px",
    lineHeight: "32px",
    color: "#4D4F59",
  },
  formDbResponseTypo: {
    fontWeight: "400",
    fontStyle: "italic",
    fontSize: "16px",
    margin: "0px",
    lineHeight: "24px",
    color: "#6C6F7C",
  },
  formAddressRadio: {
    "& span.MuiButtonBase-root": {
      padding: "0px !important",
      marginRight: "12px !important",
      height: "20px",
      width: "20px",
      background: "#F2F5FB",
      border: "1px solid #C5CEE0",
    },
    "&.MuiFormControlLabel-root": {
      marginLeft: "0",
    },
  },
  addressAddHeading: {
    display: "flex",
    justifyContent: "space-between",
  },

  boxWrapper: {
    display: "flex",
    flexFlow: "column",
    height: "100%",
    // minHeight: "80vh",
    position: "relative",
    color: "#000000",
    "& .justifyBetween": {
      justifyContent: "space-between",
    },

    // "& .MuiStepConnector-root": {
    //   marginTop: "-1.438rem",
    // },
  },

  h100: {
    overflowY: "auto",
    height: "100vh",
  },
  footer: {
    position: "fixed",
    left: "0",
    bottom: "0",
    width: "100%",
  },

  checkBoxClass: {
    "& .MuiFormControlLabel-root": {
      gap: "12px!important",
      marginLeft: "0px",
      "& .MuiButtonBase-root": {
        color: theme.palette.primary.main,
      },
    },
  },
  checkBoxConfirm: {
    "& .MuiFormControlLabel-root": {
      gap: "0px!important",
      marginLeft: "-11px",
    },
  },
  checkbox: {
    color: theme.palette.primary.main,

    "&:checked": {
      color: theme.palette.primary.main, // Set the desired color for the checked state
    },
    "&:hover": {
      backgroundColor: "#fff!important",
    },
  },

  selectMenuList: {
    height: "378px",
  },
  calenderWrap: {
    display: "flex",
    flexFlow: "column",
    justifyContent: "space-between",
    height: "100%",
    "& .react-calendar": {
      width: "100%",
      height: "auto",
      border: "none",
      fontFamily: ["Poppins", "sans-serif"].join(","),
    },
    "& .react-calendar__navigation__arrow": {
      display: "none",
    },
    "& .react-calendar__month-view__weekdays": {
      textTransform: "capitalize",
      marginBottom: "10px",
      fontSize: "12px",
      fontWeight: "500",
    },
    "& .react-calendar__month-view__days__day--weekend": {
      color: "#1F2327",
    },
    "& .react-calendar__month-view__days__day--neighboringMonth": {
      opacity: "0.3",
    },
    "& .react-calendar__tile--active": {
      background: `${theme.palette.primary.main} !important`,
      color: "#FFFFFF !important",
    },
    "& .react-calendar__navigation": {
      height: "70px",
    },
    "& .react-calendar__navigation": {
      marginTop: "1.5rem",
      marginBottom: "1rem",
      "& .react-calendar__navigation__label": {
        marginLeft: "0rem",
        paddingLeft: "24px",
        paddingRight: "24px",
        // marginBottom: "1rem",
        flexGrow: "0",
      },
      "& button": {
        marginLeft: "1.5rem",
        flexGrow: "0 !important",
        "&:hover": {
          backgroundColor: "white",
        },
      },
    },
    "& .react-calendar__navigation__label__labelText": {
      fontWeight: "300",
      fontSize: "2rem",
      fontFamily: "Poppins",
      lineHeight: "40px",
      color: " #1f2327",
    },
    "& .react-calendar__month-view__weekdays__weekday": {
      padding: "0",
    },
    "& .react-calendar__month-view__days": {
      display: "grid !important",
      gridTemplateColumns: "auto auto auto auto auto auto auto !important",
      gap: "1rem 2rem",
      width: "100%",
      margin: "auto",
      marginBottom: "1.5rem",
      padding: ".75rem 1.5rem",
      justifyContent: "space-between",
    },

    "& .available": {
      background: "#FFFFFF",
      // border: `1px solid ${theme.palette.primary.main}`,
      color: "#007BFF",
    },
    "& abbr[title]": {
      textDecoration: "none",
    },
  },

  calenderField: {
    "& button.react-calendar__tile": {
      color: "#000",
      width: "2rem",
      height: "2rem",
      borderRadius: "50%",
      padding: "1rem 0",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "1rem",
      fontFamily: "Poppins",
      fontWeight: "500",
    },
    "& .react-calendar__tile:disabled": {
      backgroundColor: "#fff",
    },
  },
  themeBtn: {
    "&.MuiButton-root": {
      padding: ".5rem .75rem !important",
      borderRadius: " 500px !important",
      fontWeight: "600",
      fontSize: ".875rem",
      lineHeight: "1rem",
      cursor: "pointer",
      marginLeft: ".25rem",
      marginRight: ".25rem",
      transition: "all 300ms ease",
      // textTransform: "none",
      // boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.15)',
      "&.btnLarge": {
        padding: "1rem 1.5rem !important",
        fontSize: "1.125rem",
        color: "#1F2327",
      },
      "&.outlined": {
        background: "#E2F0FF",
        color: "#007BFF",
        border: "1px solid #007BFF",
        "&:hover": {
          background: "#a8cff9",
        },
      },
      "&.newAddress": {
        width: "175px",
      },
      "&.filled": {
        padding: ".75rem 1.125rem !important",
        background: "#007BFF",
        color: "#fff",
        border: "1px solid #007BFF",
        "&:hover": {
          background: "#0361c6",
        },
        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.15)",
      },
      "&.primary": {
        background: "#007BFF",
        color: "#fff",
        border: "1px solid #007BFF",
        "&:hover": {
          background: "#0361c6",
        },
        "&.Mui-disabled": {
          opacity: "0.5",
        },
        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.15)",
      },
      "&.grayBtn": {
        padding: ".75rem 1.125rem !important",
        background: "#edf1f7",
        color: "#fff",
        border: "1px solid #edf1f7",
        "&:hover": {
          background: "#0361c6",
        },
        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.15)",
      },
      "&.whiteBtn": {
        background: "#ffffff",
        textTransform: "none",
        color: "#1F2327",
        border: "1px solid #ffffff",
        "& .MuiSvgIcon-root": {
          color: "#007BFF",
        },
        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.15)",
      },
      "&.serviceType": {
        fontSize: "1.125rem",
        padding: "1rem 1.5rem !important",
        fontWeight: "600",
        letterSpacing: " 0.05em",
        background: "#ffffff",
        color: "#000000",
        border: "1px solid #ffffff",
        textTransform: "capitalize",
        "&:hover": {
          background: "rgba(226, 240, 255, 1)",
          border: "1px solid #007BFF",
          color: "#007BFF",
        },
        "& .MuiButton-startIcon": {
          height: "20px",
          width: "20px",
        },
      },
      "&.Mui-disabled": {
        // opacity: "0.4",
      },
      "& .svg-inline--fa": {
        fontSize: "0.813rem !important",
      },
    },
  },
  serviceIssues: {
    "&.MuiButtonBase-root": {
      fontFamily: ["Poppins", "sans-serif"].join(","),
      background: "#F8FBFD",
      color: "black",
      border: "1px solid #D3D7E1",
      borderRadius: ".5rem",
      justifyContent: "space-between",
      fontSize: "1rem",
      lineHeight: "2rem",
      padding: ".5rem 1rem",
      fontWeight: "400",
      textTransform: "none",
    },
  },
  popupaddress: {
    width: "100%",
    padding: ".5rem",
    borderRadius: "1rem",
    boxShadow: "rgba(0, 0, 0, 0.25) 0px 14px 34px",
    background: "#fff",
    //maxWidth: "22.5rem",
    marginTop: "50px",
    margin: "auto 1.25rem",
  },
  popupcard: {
    width: "100%",
    padding: ".5rem",
    borderRadius: "1rem",
    boxShadow: "rgba(0, 0, 0, 0.25) 0px 14px 34px",
    background: "#fff",
    maxWidth: "22.5rem",
    margin: "auto 1.25rem",
  },
  overlay: {
    position: "absolute",
    width: "100%",
    height: "auto",
    top: "0",
    left: "0",
    right: "0",
    bottom: "0",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    cursor: "pointer",
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "center",
    // maxHeight:"max-content",
    // minHeight:'fit-content'
  },

  positionRelative: {
    position: "relative",
  },
  stepsProgessBar: {
    boxSizing: "border-box",
    minHeight: "88px",
    width: "100%",
    background: "#F5F8FB",
    borderBottom: "1px solid #DDE1EB",
    padding: "1rem 3.875rem 2.125rem",
    "& .MuiStepConnector-root": {
      minWidth: "3rem",
    },
    "& .MuiStepConnector-lineHorizontal": {
      borderTop: "1px dashed",
      borderColor: theme.palette.primary.main,
    },
    "& .MuiStepIcon-text": {
      fill: "#000000", //#1F2327",
    },
  },
  stepWrap: {
    position: "relative",
    "& .MuiStepLabel-iconContainer": {
      paddingRight: "0",
    },
    "& .MuiStepLabel-labelContainer": {
      width: "100%",
      position: "absolute",
      left: "-8px",
      right: "0",
      margin: "0 auto",
      bottom: "-22px",
      minWidth: "68px",
    },
    "& .MuiStepLabel-root": {
      flexDirection: "column",
      gap: "9px",
    },
    "& .MuiStepLabel-label.MuiStepLabel-active": {
      textAlign: "center",
      fontWeight: "bold",
      letterSpacing: "0.02em",
      textTransform: "uppercase",
      color: "#000000",
    },
    "& .MuiStepLabel-label": {
      fontWeight: "400",
      fontSize: ".650rem",
      lineHeight: "1rem",
      textAlign: "center",
      letterSpacing: "0.02em",
      textTransform: "uppercase",
      color: "#1f2327",
    },
    "& .MuiStepIcon-root.MuiStepIcon-active": {
      color: "white",
      border: "1px solid",
      borderColor: theme.palette.primary.main,
      borderRadius: "50%",
      "& .MuiStepIcon-text": {
        fill: "#000",
        fontWeight: "bold",
      },
    },
    "& .makeStyles-stepper-31": {
      padding: "1.5rem",
      color: "black",
      background: "#f5f8fb",
      borderBottom: "1px solid #dde1eb",
    },
    "& .MuiStepIcon-root.MuiStepIcon-completed": {
      color: theme.palette.primary.main,
    },
    "& .MuiSvgIcon-root": {
      fontSize: 24,
      strokeWidth: 0.2,
      stroke: "#C5CEE0",
      width: "2rem",
      height: "2rem",
      borderRadius: "50%",
      strokeWidth: "0",
    },
    "& .MuiStepIcon-root": {
      color: "#ffffff",
    },
  },
  rectangle: {
    paddingTop: "6.813rem",
    paddingBottom: "2.125rem",
  },
  fixBox: {
    width: "6.25rem",
    display: "block",
    fonFamily: "Poppins",
    fontStyle: "normal",
    fontWeight: "900",
    borderRadius: "1.5rem 0px",
    fontSize: "2rem",
    lineHeight: "2rem",
    marginLeft: "auto",
    paddingTop: "33px",
    marginRight: "auto",
    textAlign: "center",
    borderBottom: "10px solid #4ca2ff",
    borderRight: "10px solid #4ca2ff",
    height: "6.25rem",
    color: "white",
    background: "#007bff",
  },
  buttonsWrap: {
    display: "flex",
    flexFlow: "column",
    gap: "10px",
    alignItems: "center",
  },
  headingFour: {
    paddingTop: ".5rem",
    textAlign: "center",
    fontFamily: ["Poppins", "sans-serif"].join(","),
    fontWeight: 600,
    fontSize: "1.25rem",
    lineHeight: "1.75rem",
    color: "#1f2327",
  },
  headingSix: {
    fontWeight: "bold",
    fontSize: "1.25rem",
    lineHeight: "1.75rem",
    color: "#1f2327",
    // marginBottom: "1rem",
    "&.mb-4": {
      marginBottom: "1rem",
    },
  },

  errorMessage: {
    fontSize: "1rem",
    fontWeight: "bold",
    lineHeight: "1.5rem",
    padding: "1rem 1.5rem",
  },

  textBreadcrumb: {
    fontSize: "0.813rem",
    color: " #007BFF",
    lineHeight: "1rem",
    display: "block",
    marginBottom: "1rem !important",
  },
  titleHr: {
    width: "24px",
    padding: "1px",
    marginTop: "4px",
    marginBottom: "0px",
    border: "none",
    background: theme.palette.primary.main,
    margin: ".375rem auto 0",
  },
  jobTypeTitleIcon: {
    height: "40px",
    width: "40px",
    "& svg": {
      height: "40px",
      width: "40px",
    },
  },
  okayBtn: {
    color: "black",
    textTransform: "none",
    fontWeight: "600",
    fontSize: "1.125rem",
    lineHeight: "1.5rem",
    padding: "1rem 1.5rem",
  },
  confirmBoxInfo: {
    display: "flex",
    alignItems: "flex-start",
    "& .MuiSvgIcon-root, svg": {
      marginRight: ".875rem",
      width: "1.25rem",
    },
  },
  w100: {
    width: "100%",
  },

  [theme.breakpoints.down(600)]: {
    stepsProgessBar: {
      maxWidth: "100%",
      overflowX: "auto",
      padding: "1rem 1.5rem 2.125rem",
    },
    calenderWrap: {
      "& .react-calendar__month-view__days": {
        gap: "1rem",
        padding: "0.75rem 1.5rem",
      },
      // "& .react-calendar__navigation__label": {
      //   marginLeft: "1rem",
      // },
      "& .react-calendar__navigation": {
        "& .react-calendar__navigation__label": {
          marginLeft: ".75rem",
        },
        "& button": {
          marginLeft: ".75rem",
        },
      },
    },
    titleHr: {
      marginLeft: "auto",
      marginRight: "auto",
    },
    rectangle: {
      //paddingTop: "4rem",
    },
    formTitleDiv: {
      gap: "1rem",
    },
    flexFieldWrap: {
      gap: "1rem",
    },
    locationicon: {
      marginBottom: "0px !important",
    },
  },
  [theme.breakpoints.down(550)]: {
    locationicon: {
      marginBottom: "25px !important",
    },

    checkBoxClass: {
      paddingTop: "20px",
    },
    checkBoxConfirm: {
      paddingTop: "0px",
    },
  },
  // [theme.breakpoints.down(600)]: {

  //   formCrossIcon:{
  //     top: "125px!important",
  //     },
  // },
  [theme.breakpoints.down(564)]: {
    formCrossIcon: {
      top: "98px!important",
    },
  },

  [theme.breakpoints.down(570)]: {
    calenderWrap: {
      "& .react-calendar__month-view__days": {
        gap: "1rem",
        padding: "0.75rem 1.1rem",
      },
    },

    flexFieldWrapper: {
      flexWrap: "wrap",
    },

    radioBox: {
      "&.twoColumns": {
        gridTemplateColumns: "auto",
      },
      "&.threeColumns": {
        gridTemplateColumns: "auto auto",
      },
    },
    themeBtn: {
      "&.MuiButton-root": {
        fontSize: ".938rem !important",
        "&.filled": {
          padding: ".5rem .75rem !important",
        },
        "&.serviceType": {
          // fontSize: "1rem",
          padding: ".5rem 1rem !important",
        },
      },
    },
    serviceIssues: {
      "&.MuiButtonBase-root": {
        fontSize: ".938rem",
      },
    },
  },
  [theme.breakpoints.down(460)]: {
    calenderWrap: {
      "& .react-calendar__month-view__days": {
        gap: ".5rem",
        padding: "0.75rem 0.5rem",
      },
      "& button.react-calendar__tile": {
        fontSize: ".875rem",
      },
    },
    formDiv: {
      padding: "1.5rem 1rem",
    },
    radioBox: {
      "&.threeColumns": {
        gridTemplateColumns: "auto",
      },
    },
    themeBtn: {
      "&.MuiButton-root": {
        fontSize: ".875rem !important",
        "&.serviceType": {
          // fontSize: "1rem",
          padding: ".5rem 1rem !important",
        },
      },
    },
  },
  [theme.breakpoints.down(350)]: {
    ButtonAddress: {
      display: "flex",
      gap: "10px",
      flexDirection: "column",
    },
    formCrossIcon: {
      top: "75px!important",
    },
  },
}));

export default appointmentFormStyle;
