import * as Yup from "yup";
import { getExistingCustomer } from "../../../api/services";

const phoneRegExp = /^(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/gm;

export const clientDetailSchema = Yup.object().shape({
  cName: Yup.string().required("Customer Name is required"),
  phoneNumber: Yup.string()
    .required("Phone number is required")
    .matches(phoneRegExp, "Phone number is not valid"),
  email: Yup.string()
    .required("Email is required")
    .email("Invalid email address"),
});

export const existClientDetailSchema = Yup.object().shape({
  accountPhoneNumber: Yup.string()
    .required("Account phone number is required")
    .matches(phoneRegExp, "Account phone number is not valid"),
});

export const clientAddressSchema = Yup.object().shape({
  streetAddress: Yup.string().required("Street address is required"),
  // unitNumber: Yup.string().required("Unit number is required"),
  city: Yup.string().required("city is required"),
  state: Yup.string().required("state is required"),
  zipCode: Yup.string().required("zip code is required"),
  // isOwner: Yup.bool().oneOf([true], "You need to accept own residence"),
});
