import React, { useEffect, useState } from "react";
import Calendar from "react-calendar";
import { Typography } from "@material-ui/core";
import moment from "moment";
import "react-calendar/dist/Calendar.css";
//import Calendar from '../Appointment/Calendar';
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import appointmentFormStyle from "../styles";
import { useFormikContext } from "formik";

import { getAvailableSlots } from "../../../api/services";

function Appointment(props) {
  const {
    setIsNextdisabled,
    availableSlots,
    availableDates,
    appointmentObj,
    setIsLoading,
    IsAvialableSlotsCompleted,
  } = props;
  const classes = appointmentFormStyle();
  const { setFieldValue, values } = useFormikContext();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState([]);

  useEffect(() => {
    //setIsNextdisabled(true);
    setIsNextdisabled(false);
  }, []);

  useEffect(() => {
    if (availableDates !== undefined && availableDates?.length > 0) {
      setSelectedDate(availableDates[0]);
      setSelectedTime(availableSlots[availableDates[0]]);
      setFieldValue("appointmentDate", availableDates[0]);
      setFieldValue("appointmentTime", availableSlots[availableDates[0]]);
    } else {
      setIsNextdisabled(true);
    }

    if (
      appointmentObj?.customerId !== "" &&
      appointmentObj?.customerId !== undefined
    ) {
      setFieldValue("appointmentObj", appointmentObj);
    }
  }, [availableSlots, availableDates, appointmentObj]);

  const tileClassName = ({ date }) => {
    const dateStr = moment(date).format("YYYY-MM-DD");
    if (availableDates?.includes(dateStr)) {
      return "available";
    } else {
      return "notAvailable";
    }
  };

  const tileDisabled = ({ date }) => {
    const dateStr = moment(date).format("YYYY-MM-DD");
    if (availableDates?.includes(dateStr)) {
      return false;
    } else {
      return true;
    }
  };

  const _handleDateChange = (date) => {
    const dateStr = moment(date).format("YYYY-MM-DD");
    setSelectedDate(dateStr);
    setSelectedTime(availableSlots[dateStr]);
    setFieldValue("appointmentDate", dateStr);
  };

  const _handleTimeChange = (time) => {
    setFieldValue("appointmentTime", time);
    setIsNextdisabled(false);
  };

  return (
    <div className={classes.calenderWrap}>
      <Calendar
        onChange={_handleDateChange}
        value={selectedDate}
        calendarType="US"
        tileClassName={tileClassName}
        tileDisabled={tileDisabled}
        className={classes.calenderField}
      />
      <div
        className="radio-text"
        style={{
          background: "#F2F0FA",
          paddingBottom: "3.313rem",
          height: "100%",
        }}
      >
        {IsAvialableSlotsCompleted && (
          <>
            {" "}
            {selectedTime.length > 0 ? (
              <>
                <RadioGroup
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    paddingTop: "16px",
                    paddingLeft: "20px",
                  }}
                  aria-labelledby="demo-controlled-radio-buttons-group"
                  name="appointmentTime"
                >
                  {selectedTime.length > 0 &&
                    selectedTime.map((time, index) => {
                      const startTime = moment(time?.start, "HH:mm").format(
                        "h:mm A"
                      );
                      const endTime = moment(time?.end, "HH:mm").format(
                        "h:mm A"
                      );
                      return (
                        <FormControlLabel
                          key={index}
                          id={`timeId-${index}`}
                          value={`${time?.start}-${time?.end}`}
                          onChange={() => _handleTimeChange(time)}
                          control={<Radio />}
                          label={`${startTime} - ${endTime} EST`}
                        />
                      );
                    })}
                </RadioGroup>
                {/*  <Typography
              variant="p"
              style={{
                paddingLeft: "1.5rem",
                paddingTop: "1rem",
                display: "block",
                fontSize: ".938rem",
                lineHeight: "1.5rem",
                color: "#6C6F7C",
                fontStyle: "italic",
              }}
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
              interdum, diam vel fermentum posuere, enim massa.
            </Typography> */}
              </>
            ) : (
              <Typography
                variant="p"
                color="error"
                style={{
                  paddingLeft: "1.5rem",
                  paddingTop: "1rem",
                  display: "block",
                  fontSize: ".938rem",
                  lineHeight: "1.5rem",
                  fontStyle: "italic",
                }}
              >
                No schedule available for this date. Please select different
                date.
              </Typography>
            )}
          </>
        )}
      </div>
    </div>
  );
}
export default Appointment;
