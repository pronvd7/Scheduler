export const steps = [
  "CLIENT INFO",
  "PROBLEM",
  "DESCRIPTION",
  "APPOINTMENT",
  "CONFIRM",
];

export const clientSteps = [
  "Customer Type",
  "Customer Info",
  "Customer Address",
];

export const problemSteps = ["Service Select", "Service Type", "Issues Step"];
export const descriptionSteps = [
  /* "QuestionScreenOne",
  "QuestionScreenTwo",
  "QuestionScreenThree",
  "QuestionScreenFour", */
  "systemAge",
  "Diagnostic Fee",
  "Additional Info",
];
