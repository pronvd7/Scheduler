import React, { useState, useEffect } from "react";
import { Box } from "@mui/material";
import { Typography, Button } from "@material-ui/core";
import { HeatingIcon, Plumbing, Electrical } from "../../Icons";
import { SvgIcon } from "@mui/material";
import { useQuery } from "react-query";
import axios from "axios";
import appointmentFormStyle from "../styles";

import { useFormikContext } from "formik";

const IssuesStep = (props) => {
  const { _handleNext, setActiveStepColor, _handleDescriptionSteps } = props;
  const classes = appointmentFormStyle();
  const formikActions = useFormikContext();
  const { setFieldValue, values } = formikActions;
  const { service, serviceType, selectedData } = values;

  useEffect(() => {
    setActiveStepColor("#FFFFFF");
  }, []);

  const _handleOptionsChange = (questionsData) => {
    _handleDescriptionSteps(questionsData);
  };

  return (
    <div className={classes.formDiv}>
      <Box component="p" variant="p" className={classes.textBreadcrumb}>
        {`${selectedData?.service} - ${selectedData?.serviceType}`}
      </Box>
      <Box
        component="div"
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: "1rem",
        }}
      >
        <Typography variant="h6" mb="0" className={classes.headingSix}>
          {service}
          <hr
            className={classes.titleHr}
            style={{
              marginLeft: "0px",
            }}
          ></hr>
        </Typography>
        <Box
          className={classes.jobTypeTitleIcon}
          style={{
            height: "40px",
            width: "40px",
            marginBottom: "0",
            marginRight: "0",
            minWidth: "3.125rem",
            display: "inline-block",
          }}
        >
          {service === "Heating & Cooling" && (
            <SvgIcon component={HeatingIcon} />
          )}
          {service === "Plumbing" && <SvgIcon component={Plumbing} />}
          {service === "Electrical" && <SvgIcon component={Electrical} />}
        </Box>
      </Box>
      <div
        className="heatstep"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px",
          // width: "512px",
          margin: "auto",
        }}
      >
        {React.Children.toArray(
          serviceType?.data?.map((item) => (
            <Button
              className={classes.serviceIssues}
              name="serviceCategory"
              key={item?.id}
              value={item?.label}
              onClick={() => {
                setFieldValue("serviceCategory", item.id);

                if (item?.jobType !== undefined) {
                  setFieldValue("selectedData", {
                    ...selectedData,
                    serviceCategory: item.id,
                    remType: item?.remType ? item?.remType : "",
                    jobType: selectedData?.subJobType
                      ? `${item?.jobType}: ${selectedData?.subJobType}`
                      : item?.jobType,
                  });
                } else {
                  setFieldValue("selectedData", {
                    ...selectedData,
                    serviceCategory: item.id,
                    remType: item?.remType ? item?.remType : "",
                  });
                }

                if (item?.data !== undefined && item?.data?.length > 0) {
                  setFieldValue("questionsData", item.data);
                  _handleOptionsChange(item.data);
                } else {
                  setFieldValue("questionsData", []);
                  _handleOptionsChange([]);
                }
                _handleNext();
              }}
              endIcon={
                <img
                  src="/right-angle.svg"
                  alt="right-angle"
                  title="right-angle"
                />
              }
            >
              {item?.label}
            </Button>
          ))
        )}
      </div>
    </div>
  );
};

export default IssuesStep;
