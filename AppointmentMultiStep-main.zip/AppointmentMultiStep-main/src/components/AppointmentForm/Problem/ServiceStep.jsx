import React, { useEffect } from "react";
import {
  FormControl,
  FormControlLabel,
  Radio,
  Box,
  RadioGroup,
  Typography,
  makeStyles,
} from "@material-ui/core";
import { Heating, Plumbing, Electrical } from "../../Icons";
import { SvgIcon } from "@mui/material";
import appointmentFormStyle from "../styles";
import { useFormikContext } from "formik";

const ServiceStep = (props) => {
  const classes = appointmentFormStyle();
  const { setFieldValue, values } = useFormikContext();

  const services = [
    { id: "Plumbing", label: "Plumbing", icon: Plumbing },
    { id: "Heating & Cooling", label: "Heating & Cooling", icon: Heating },
    { id: "Electrical", label: "Electrical", icon: Electrical },
  ];

  const { _handleNextStep, setActiveStepColor } = props;
  const [selectedOption, setSelectedOption] = React.useState("");

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
    setFieldValue("service", event.target.value);
    setFieldValue("selectedData", {
      ...values?.selectedData,
      service: event.target.value,
    });
    _handleNextStep();
  };

  useEffect(() => {
    setActiveStepColor("#FFFFFF");
  }, []);

  return (
    <Box className={classes.formDiv}>
      <Typography variant="h6" className={classes.headingSix}>
        What do you need help with?
        <hr
          className={classes.titleHr}
          style={{
            marginLeft: "0px",
          }}
        ></hr>
      </Typography>
      <FormControl
        style={{
          display: "grid",
        }}
        component="fieldset"
      >
        <RadioGroup
          className={`twoColumns ${classes.radioBox}`}
          value={selectedOption}
          defaultValue={selectedOption}
          onChange={handleOptionChange}
        >
          {services.map((service) => (
            <FormControlLabel
              key={service?.id}
              value={service?.label}
              control={<Radio style={{ display: "none" }} />}
              style={{
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                padding: "1rem",
                background: "#FFFFFF",
                borderRadius: "1rem",
                cursor: "pointer",
                border: "1px solid #D3D7E1",
                marginLeft: "0",
                marginRight: "0",
              }}
              label={
                <Box>
                  <Box style={{ textAlign: "center", marginBottom: "0.5rem" }}>
                    <SvgIcon component={service?.icon} />
                  </Box>
                  <Typography
                    style={{
                      fontSize: ".938rem",
                      fontWeight: "500",
                      textAlign: "center",
                      lineHeight: "1.25rem",
                    }}
                  >
                    {service?.label}
                  </Typography>
                </Box>
              }
              classes={{ root: classes.myFormControlLabelRoot }}
            />
          ))}
        </RadioGroup>
      </FormControl>
    </Box>
  );
};

export default ServiceStep;
