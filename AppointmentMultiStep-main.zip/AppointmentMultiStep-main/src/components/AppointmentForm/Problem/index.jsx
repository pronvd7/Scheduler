import React, { useEffect, useState } from "react";
import { Button } from "@material-ui/core";
import ServiceStep from "./ServiceStep";
import ServiceTypeStep from "./ServiceTypeStep";
import IssuesStep from "./IssuesStep";
import useStyles from "../styles";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeftLong } from "@fortawesome/free-solid-svg-icons";
//import ArrowBackIcon from '@mui/icons-material/ArrowBack';
// import WestIcon from '@mui/icons-material/West';

export default function Problem(props) {
  const {
    _handleNext,
    problemActiveStep,
    setActiveStepColor,
    _handleProblemBack,
    _handleDescriptionSteps,
  } = props;
  const classes = useStyles();

  function _renderStepContent(step) {
    switch (step) {
      case 0:
        return (
          <ServiceStep
            _handleNextStep={_handleNext}
            setActiveStepColor={setActiveStepColor}
          />
        );

      case 1:
        return (
          <ServiceTypeStep
            _handleNextStep={_handleNext}
            setActiveStepColor={setActiveStepColor}
          />
        );
      case 2:
        return (
          <IssuesStep
            _handleNext={_handleNext}
            setActiveStepColor={setActiveStepColor}
            _handleDescriptionSteps={_handleDescriptionSteps}
          />
        );

      default:
        return <div>Not Found</div>;
    }
  }

  return (
    <React.Fragment>
      {_renderStepContent(problemActiveStep)}

      {
        /* problemActiveStep !== 0 && ( */
        <div>
          {problemActiveStep === 1 ? (
            <div style={{ textAlign: "center" }}>
              {" "}
              <Button
                variant="contained"
                color="primary"
                onClick={_handleProblemBack}
                className={`outlined ${classes.themeBtn}`}
                startIcon={<FontAwesomeIcon icon={faArrowLeftLong} />}
              >
                Back
              </Button>
            </div>
          ) : (
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                padding: ".5rem",
                width: "100%",
                background: "#F2F5FB",
              }}
            >
              <Button
                className={`whiteBtn ${classes.themeBtn}`}
                startIcon={<FontAwesomeIcon icon={faArrowLeftLong} />}
                variant="contained"
                onClick={_handleProblemBack}
              >
                {" "}
                Back
              </Button>
            </div>
          )}
        </div>
        /*) */
      }
    </React.Fragment>
  );
}
