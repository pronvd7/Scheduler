import React, { useEffect } from "react";
import { Typography } from "@material-ui/core";
import { Button } from "@material-ui/core";

import { RepeatIcon, EventIcon } from "../../Icons";
import { SvgIcon } from "@mui/material";
import appointmentFormStyle from "../styles";
import { useFormikContext } from "formik";
import { serviceTypeList } from "../../../api/appointmentQuestions";

const ServiceTypeStep = (props) => {
  const { _handleNextStep, setActiveStepColor } = props;
  const classes = appointmentFormStyle();
  const { setFieldValue, values } = useFormikContext();
  const { selectedData, service } = values;

  /*const serviceTypeList = [
    {
      id: 1,
      label: <>Repair and service</>,
      value: "repair",
      data: subCategories?.repair,
      icon: (
        <img src="/repair-tools.svg" alt="repair-tools" title="repair-tools" />
      ),
    },
    {
      id: 2,
      label: <>New equipment estimate </>,
      value: "estimate",
      data: subCategories?.estimate,
      icon: <SvgIcon component={RepeatIcon} />,
    },
    {
      id: 3,
      label: <>Preventive maintenance</>,
      value: "maintenance",
      data: subCategories?.maintenance,
      icon: <SvgIcon component={EventIcon} />,
    },
  ];
 */
  useEffect(() => {
    setActiveStepColor("#F2F0FA");
  }, []);

  return (
    <div className={classes.formDiv}>
      <Typography
        variant="h6"
        className={classes.headingSix}
        gutterBottom
        style={{ textAlign: "center", marginBottom: "1.5rem" }}
      >
        What type of service do you need?
        <hr className={classes.titleHr}></hr>
      </Typography>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "1.5rem",
          justifyContent: "center",
          marginTop: ".5rem",
        }}
      >
        {React.Children.toArray(
          serviceTypeList?.[service].map((item, index) => (
            <Button
              variant="outlined"
              className={`serviceType whiteBtn ${classes.themeBtn}`}
              name="serviceType"
              key={`${index}-${item?.id}`}
              value={item?.label}
              onClick={(event) => {
                setFieldValue("serviceType", {
                  type: item?.id,
                  data: item?.data,
                });
                setFieldValue("selectedData", {
                  ...selectedData,
                  serviceType: item?.id,
                });
                _handleNextStep();
              }}
              startIcon={item?.icon}
            >
              {item?.label}
            </Button>
          ))
        )}
      </div>
    </div>
  );
};
export default ServiceTypeStep;
