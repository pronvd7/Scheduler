import axios from "axios";

const axiosInstance = axios.create({
  baseURL: process.env.API_URL
    ? process.env.API_URL
    : `https://us-central1-autobot-v1-356820.cloudfunctions.net`,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use(
  (config) => {
    // Add any authorization headers or other request transformations here
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    // Handle any successful responses here
    return response;
  },
  (error) => {
    // Handle any errors that come back from the API here
    return Promise.reject(error);
  }
);

export default axiosInstance;
