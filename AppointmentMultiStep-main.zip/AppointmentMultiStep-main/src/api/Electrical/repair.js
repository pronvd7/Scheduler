export const electricalRepair = [
  {
    id: "Indoors",
    label: <>Indoors</>,
    data: [
      [
        {
          name: "Indoors",
          question: "Indoors",
          answers: [
            {
              id: "Switches, Outlets, & Fixtures",
              label: <>Switches, Outlets, & Fixtures</>,
              value: "Switches, Outlets, & Fixtures",
              jobType: "Switches, Outlets, Fixtures",
            },
            {
              id: "Breaker Panel",
              label: <>Breaker Panel</>,
              value: "Breaker Panel",
              jobType: "Breaker Panel",
            },
            {
              id: "Ceiling Fan",
              label: <>Ceiling Fan</>,
              value: "Ceiling Fan",
              jobType: "Ceiling Fan",
            },
            {
              id: "Exhaust Fan",
              label: <>Exhaust Fan</>,
              value: "Exhaust Fan",
              jobType: "Exhaust Fan",
            },
            {
              id: "Surge Protector",
              label: <>Surge Protector</>,
              value: "Surge Protector",
              jobType: "Surge Protector",
            },
            {
              id: "Smart Home",
              label: <>Smart Home</>,
              value: "Smart Home",
              jobType: "Smart Home",
            },
            {
              id: "Lighting",
              label: <>Lighting</>,
              value: "Lighting",
              jobType: "Lighting",
            },
            {
              id: "Wiring",
              label: <>Wiring</>,
              value: "Wiring",
              jobType: "Wiring",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Outdoors",
    label: <>Outdoors</>,
    data: [
      [
        {
          name: "Outdoors",
          question: "Outdoors",
          answers: [
            {
              id: "Security/Motion Lights",
              label: <>Security/Motion Lights</>,
              value: "Security/Motion Lights",
              jobType: "Security/Motion Light",
            },
            {
              id: "Outdoor Outlet",
              label: <>Outdoor Outlet</>,
              value: "Outdoor Outlet",
              jobType: "Outdoor Outlet",
            },
            {
              id: "Outdoor Lighting",
              label: <>Outdoor Lighting</>,
              value: "Outdoor Lighting",
              jobType: "Outdoor Lighting",
            },
            {
              id: "Meter Base",
              label: <>Meter Base</>,
              value: "Meter Base",
              jobType: "Meter Base",
            },
            {
              id: "Lightning Protection",
              label: <>Lightning Protection</>,
              value: "Lightning Protection",
              jobType: "Lightning Protection",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Vehicle Charging Station",
    label: <>Vehicle Charging Station</>,
    jobType: "Vehicle Charging Station",
    data: [],
  },
  {
    id: "Hot Tub Wiring",
    label: <>Hot Tub Wiring</>,
    jobType: "Hot Tub Wiring",
    data: [],
  },
];
