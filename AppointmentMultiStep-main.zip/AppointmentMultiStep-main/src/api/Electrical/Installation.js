export const electricalInstallation = [
  {
    id: "Indoors",
    label: <>Indoors</>,
    data: [
      [
        {
          name: "Indoors",
          question: "Indoors",
          answers: [
            {
              id: "Switches, Outlets, & Fixtures",
              label: <>Switches, Outlets, & Fixtures</>,
              value: "Switches, Outlets, & Fixtures",
              jobType: "Switches, Outlets, Fixtures",
            },
            {
              id: "Lighting",
              label: <>Lighting</>,
              value: "Lighting",
              jobType: "Indoor Lighting",
            },
            {
              id: "Breaker Panel",
              label: <>Breaker Panel</>,
              value: "Breaker Panel",
              jobType: "Breaker Panel",
            },
            {
              id: "Ceiling Fan",
              label: <>Ceiling Fan</>,
              value: "Ceiling Fan",
              jobType: "Ceiling Fan",
            },
            {
              id: "Exhaust Fan",
              label: <>Exhaust Fan</>,
              value: "Exhaust Fan",
              jobType: "Exhaust Fan",
            },
            {
              id: "Surge Protector",
              label: <>Surge Protector</>,
              value: "Surge Protector",
              jobType: "Surge Protector",
            },
            {
              id: "Entertainment Center Wiring",
              label: <>Entertainment Center Wiring</>,
              value: "Entertainment Center Wiring",
              jobType: "Entertainment Center Wiringe",
            },
            {
              id: "Smoke/Carbon Monoxide Detectors",
              label: <>Smoke/Carbon Monoxide Detectors</>,
              value: "Smoke/Carbon Monoxide Detectors",
              jobType: "Smoke & Carbon Monoxide Detectors",
            },
            {
              id: "Smart Home",
              label: <>Smart Home</>,
              value: "Smart Home",
              jobType: "Smart Home",
            },
            {
              id: "Hot Tub Wiring",
              label: <>Hot Tub Wiring</>,
              value: "Hot Tub Wiring",
              jobType: "Hot Tub Wiring",
            },
            {
              id: "Wiring",
              label: <>Wiring</>,
              value: "Wiring",
              jobType: "Wiring",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Outdoors",
    label: <>Outdoors</>,
    data: [
      [
        {
          name: "Outdoors",
          question: "Outdoors",
          answers: [
            {
              id: "Security/Motion Lights",
              label: <>Security/Motion Lights</>,
              value: "Security/Motion Lights",
              jobType: "Security/Motion Light",
            },
            {
              id: "Outdoor Outlet",
              label: <>Outdoor Outlet</>,
              value: "Outdoor Outlet",
              jobType: "Outdoor Outlet",
            },
            {
              id: "Outdoor Lighting",
              label: <>Outdoor Lighting</>,
              value: "Outdoor Lighting",
              jobType: "Outdoor Lighting",
            },
            {
              id: "Meter Base",
              label: <>Meter Base</>,
              value: "Meter Base",
              jobType: "Meter Base",
            },
            {
              id: "Lightning Protection",
              label: <>Lightning Protection</>,
              value: "Lightning Protection",
              jobType: "Lightning Protection",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Vehicle Charging Station",
    label: <>Vehicle Charging Station</>,
    value: "Vehicle Charging Station",
    jobType: "Vehicle Charging Station",
  },
  {
    id: "Home Remodel",
    label: <>Home Remodel</>,
    value: "Home Remodel",
    jobType: "Home Remodels",
  },
];
