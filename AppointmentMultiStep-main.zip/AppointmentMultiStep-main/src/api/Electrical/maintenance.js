export const ElectricalMaintenance = [
  {
    id: "Member Maintenance",
    label: <>Member Maintenance</>,
    jobType: "Electrical Inspection: Member",
    data: [],
  },
  {
    id: "Generator Maintenance",
    label: <>Generator Maintenance</>,
    data: [
      [
        {
          name: "GeneratorMaintenance",
          question: "Are you a maintenance program member?",
          answers: [
            {
              id: "Yes",
              label: <>Yes</>,
              value: "Yes",
              jobType: "Generator: Member",
            },
            {
              id: "No",
              label: <>No</>,
              value: "No",
              jobType: "Generator: Non-Member",
            },
          ],
        },
      ],
    ],
  },

  {
    id: "Electrical Inspection",
    label: <>Electrical Inspection</>,
    data: [
      [
        {
          name: "ElectricalInspection",
          question: "Are you a maintenance program member?",
          answers: [
            {
              id: "Yes",
              label: <>Yes</>,
              value: "Yes",
              jobType: "Electrical Inspection: Member",
            },
            {
              id: "No",
              label: <>No</>,
              value: "No",
              jobType: "Electrical Inspection: Non-Member",
            },
          ],
        },
      ],
    ],
  },
];
