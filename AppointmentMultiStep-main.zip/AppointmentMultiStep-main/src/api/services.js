import AxiosAPI from "./axiosInstance";

export const getSchedulerData = async () => {
  const response = await AxiosAPI.post(`/scheduler_get_start`, {
    websiteUrl: "https://www.cardinalplumbingva.com/",
  });
  return response.data;
};

export const getExistingCustomer = async (accountPhoneNumber) => {
  const response = await AxiosAPI.post(`/scheduler_get_customer`, {
    websiteUrl: "https://www.cardinalplumbingva.com/",
    phone: accountPhoneNumber,
  });
  return response.data;
};

export const createCustomer = async (customerDetail) => {
  const response = await AxiosAPI.post(`/scheduler_create_customer`, {
    ...customerDetail,
    websiteUrl: "https://www.cardinalplumbingva.com/",
  });
  return response.data;
};

export const createAddress = async (addressDetail) => {
  const response = await AxiosAPI.post(`/scheduler_create_address`, {
    ...addressDetail,
    websiteUrl: "https://www.cardinalplumbingva.com/",
  });
  return response.data;
};

export const getAvailableSlots = async (serviceDetail) => {
  const response = await AxiosAPI.post(`/scheduler_get_times`, {
    ...serviceDetail,
    websiteUrl: "https://www.cardinalplumbingva.com/",
  });
  return response.data;
};

export const createAppointement = async (appointmentDetail) => {
  const response = await AxiosAPI.post(`/scheduler_post_appointment`, {
    appointmentObj: { ...appointmentDetail },
    websiteUrl: "https://www.cardinalplumbingva.com/",
  });
  return response.data;
};

export const validationAddress = async (payload) => {
  const address = {
    address: payload,
    enableUspsCass: true,
  };

  return fetch(
    `https://addressvalidation.googleapis.com/v1:validateAddress?key=${process.env.REACT_APP_GOOGLE_API_KEY}`,
    {
      method: "POST",
      body: JSON.stringify(address),
      headers: { "Content-Type": `application/json` },
    }
  ).then((response) => {
    return response.json();
  });
};
