export const HeatingCoolingMaintenance = [
  {
    id: "Cooling Tune-Up",
    label: <>Cooling Tune-Up</>,
    data: [
      [
        {
          name: "isSystemWorking",
          question: "Is your current system working properly?",
          answers: [
            {
              id: "Yes",
              label: "Yes",
              value: "Yes",
              data: [
                {
                  name: "memberType",
                  question: "Are you a maintenance program member?",
                  answers: [
                    {
                      id: "Yes",
                      label: <>Yes</>,
                      value: "Yes",
                      subJobType: "Member",
                    },
                    {
                      id: "No",
                      label: <>No</>,
                      value: "No",
                      subJobType: "Non-Member",
                    },
                  ],
                },
              ],
              subQuestionData: [
                ["firstStepQuestions"],
                [
                  {
                    name: "equipmentAge",
                    question: "How old is your equipment?",
                    answers: [
                      {
                        id: "0-5 Years",
                        label: <>0-5 Years</>,
                        value: "0-5 Years",
                      },
                      {
                        id: "6-10 Years",
                        label: <>6-10 Years</>,
                        value: "6-10 Years",
                      },
                      {
                        id: "11+ Years",
                        label: <>11+ Years</>,
                        value: "11+ Years",
                      },
                      {
                        id: "Not Sure",
                        label: <>Not Sure</>,
                        value: "Not Sure",
                      },
                    ],
                  },
                  {
                    name: "How-many-systems-need-serviced",
                    question: "How many systems do you need serviced?",
                    answers: [
                      {
                        id: "One",
                        label: <>One</>,
                        value: "One",
                      },
                      {
                        id: "Two",
                        label: <>Two</>,
                        value: "Two",
                      },
                      {
                        id: "Three",
                        label: <>Three</>,
                        value: "Three",
                      },
                      {
                        id: "Four",
                        label: <>Four</>,
                        value: "Four",
                      },
                      {
                        id: "Unsure",
                        label: <>Unsure</>,
                        value: "Unsure",
                      },
                    ],
                  },
                ],
                [
                  {
                    name: "equipmentType",
                    question: "What kind of equipment do you have?",
                    answers: [
                      {
                        id: "Central A/C",
                        label: <>Central A/C</>,
                        value: "Central A/C",
                        jobType: "Central A/C",
                      },
                      {
                        id: "Mini-Split/Ductless",
                        label: <>Mini-Split/Ductless</>,
                        value: "Mini-Split/Ductless",
                        jobType: "Ductless Mini-Split A/C",
                      },
                      {
                        id: "Geo-Thermal",
                        label: <>Geo-Thermal</>,
                        value: "Geo-Thermal",
                        jobType: "Geo Thermal Cooling System",
                      },
                      {
                        id: "Heat Pump",
                        label: <>Heat Pump</>,
                        value: "Heat Pump",
                        jobType: "Heat Pump",
                      },
                      {
                        id: "Swamp Cooler",
                        label: <>Swamp Cooler</>,
                        value: "Swamp Cooler",
                        jobType: "Swamp Cooler",
                      },
                      {
                        id: "Outdoor Mist System",
                        label: <>Outdoor Mist System</>,
                        value: "Outdoor Mist System",
                        jobType: "Outdoor Mist Cooling System",
                      },
                      {
                        id: "Window A/C Unit",
                        label: <>Window A/C Unit</>,
                        value: "Window A/C Unit",
                        jobType: "Window A/C Unit",
                      },
                      {
                        id: "Whole House Fan",
                        label: <>Whole House Fan</>,
                        value: "Whole House Fan",
                        jobType: "Whole House Fan",
                      },
                    ],
                  },
                ],
              ],
            },
            {
              id: "No",
              label: "No",
              value: "No",
              data: [
                {
                  name: "equipmentType",
                  question: "What kind of equipment do you have?",
                  answers: [
                    {
                      id: "Central A/C",
                      label: <>Central A/C</>,
                      value: "Central A/C",
                      jobType: "Central A/C",
                    },
                    {
                      id: "Mini-Split/Ductless",
                      label: <>Mini-Split/Ductless</>,
                      value: "Mini-Split/Ductless",
                      jobType: "Ductless Mini-Split A/C",
                    },
                    {
                      id: "Geo-Thermal",
                      label: <>Geo-Thermal</>,
                      value: "Geo-Thermal",
                      jobType: "Geo Thermal Cooling System",
                    },
                    {
                      id: "Heat Pump",
                      label: <>Heat Pump</>,
                      value: "Heat Pump",
                      jobType: "Heat Pump",
                    },
                    {
                      id: "Swamp Cooler",
                      label: <>Swamp Cooler</>,
                      value: "Swamp Cooler",
                      jobType: "Swamp Cooler",
                    },
                    {
                      id: "Outdoor Mist System",
                      label: <>Outdoor Mist System</>,
                      value: "Outdoor Mist System",
                      jobType: "Outdoor Mist Cooling System",
                    },
                    {
                      id: "Window A/C Unit",
                      label: <>Window A/C Unit</>,
                      value: "Window A/C Unit",
                      jobType: "Window A/C Unit",
                    },
                    {
                      id: "Whole House Fan",
                      label: <>Whole House Fan</>,
                      value: "Whole House Fan",
                      jobType: "Whole House Fan",
                    },
                    {
                      id: "Unsure",
                      label: <>Unsure</>,
                      value: "Unsure",
                      jobType: "HVAC: Unsure Equipment",
                    },
                  ],
                },
              ],
              subQuestionData: [
                ["firstStepQuestions"],
                [
                  {
                    name: "equipmentAge",
                    question: "How old is your equipment?",
                    answers: [
                      {
                        id: "0-5 Years",
                        label: <>0-5 Years</>,
                        value: "0-5 Years",
                      },
                      {
                        id: "6-10 Years",
                        label: <>6-10 Years</>,
                        value: "6-10 Years",
                      },
                      {
                        id: "11+ Years",
                        label: <>11+ Years</>,
                        value: "11+ Years",
                      },
                      {
                        id: "Not Sure",
                        label: <>Not Sure</>,
                        value: "Not Sure",
                      },
                    ],
                  },
                ],
              ],
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Heating Tune-Up",
    label: <>Heating Tune-Up</>,
    data: [
      [
        {
          name: "isSystemWorking",
          question: "Is your current system working properly?",
          answers: [
            {
              id: "Yes",
              label: "Yes",
              value: "Yes",
              data: [
                {
                  name: "memberType",
                  question: "Are you a maintenance program member?",
                  answers: [
                    {
                      id: "Yes",
                      label: <>Yes</>,
                      value: "Yes",
                      jobType: "Heating System: Member",
                    },
                    {
                      id: "No",
                      label: <>No</>,
                      value: "No",
                      jobType: "Heating System: Non-Member",
                    },
                  ],
                },
              ],
              subQuestionData: [
                ["firstStepQuestions"],
                [
                  {
                    name: "equipmentAge",
                    question: "How old is your equipment?",
                    answers: [
                      {
                        id: "0-5 Years",
                        label: <>0-5 Years</>,
                        value: "0-5 Years",
                      },
                      {
                        id: "6-10 Years",
                        label: <>6-10 Years</>,
                        value: "6-10 Years",
                      },
                      {
                        id: "11+ Years",
                        label: <>11+ Years</>,
                        value: "11+ Years",
                      },
                      {
                        id: "Not Sure",
                        label: <>Not Sure</>,
                        value: "Not Sure",
                      },
                    ],
                  },
                  {
                    name: "How-many-systems-need-serviced",
                    question: "How many systems do you need serviced?",
                    answers: [
                      {
                        id: "One",
                        label: <>One</>,
                        value: "One",
                      },
                      {
                        id: "Two",
                        label: <>Two</>,
                        value: "Two",
                      },
                      {
                        id: "Three",
                        label: <>Three</>,
                        value: "Three",
                      },
                      {
                        id: "Four",
                        label: <>Four</>,
                        value: "Four",
                      },
                      {
                        id: "Unsure",
                        label: <>Unsure</>,
                        value: "Unsure",
                      },
                    ],
                  },
                ],
              ],
            },
            {
              id: "No",
              label: "No",
              value: "No",
              data: [
                {
                  name: "equipmentType",
                  question: "What kind of equipment do you have?",
                  answers: [
                    {
                      id: "Oil Boiler",
                      label: <>Oil Boiler</>,
                      value: "Oil Boiler",
                      jobType: "Oil Boiler",
                    },
                    {
                      id: "Heat Pump",
                      label: <>Heat Pump</>,
                      value: "Heat Pump",
                      jobType: "Heat Pump",
                    },
                    {
                      id: "Geo-Thermal",
                      label: <>Geo-Thermal</>,
                      value: "Geo-Thermal",
                      jobType: "Geo Thermal Heating System",
                    },
                    {
                      id: "Mini-Split/Ductless",
                      label: <>Mini-Split/Ductless</>,
                      value: "Mini-Split/Ductless",
                      jobType: "Ductless Mini-Split Heating",
                    },
                    {
                      id: "Gas Furnace",
                      label: <>Gas Furnace</>,
                      value: "Gas Furnace",
                      jobType: "Gas Furnace",
                    },
                    {
                      id: "Oil Furnace",
                      label: <>Oil Furnace</>,
                      value: "Oil Furnace",
                      jobType: "Oil Furnace",
                    },
                    {
                      id: "Gas Boiler",
                      label: <>Gas Boiler</>,
                      value: "Gas Boiler",
                      jobType: "Gas Boiler",
                    },
                    {
                      id: "Electric Wall Heater",
                      label: <>Electric Wall Heater</>,
                      value: "Electric Wall Heater",
                      jobType: "Electrical Wall Heater",
                    },
                    {
                      id: "Electric Furnace",
                      label: <>Electric Furnace</>,
                      value: "Electric Furnace",
                      jobType: "Electric Furnace",
                    },
                    {
                      id: "Electric Boiler",
                      label: <>Electric Boiler</>,
                      value: "Electric Boiler",
                      jobType: "Electric Boiler",
                    },
                    {
                      id: "Radiant Floor Heater",
                      label: <>Radiant Floor Heater</>,
                      value: "Radiant Floor Heater",
                      jobType: "Radiant Floor Heating System",
                    },
                    {
                      id: "Radiant Panel Heater",
                      label: <>Radiant Panel Heater</>,
                      value: "Radiant Panel Heater",
                      jobType: "Radiant Panel Heating Units",
                    },
                    {
                      id: "Unsure",
                      label: <>Unsure</>,
                      value: "Unsure",
                      jobType: "HVAC: Unsure Equipment",
                    },
                  ],
                },
              ],
              subQuestionData: [
                ["firstStepQuestions"],
                [
                  {
                    name: "equipmentAge",
                    question: "How old is your equipment?",
                    answers: [
                      {
                        id: "0-5 Years",
                        label: <>0-5 Years</>,
                        value: "0-5 Years",
                      },
                      {
                        id: "6-10 Years",
                        label: <>6-10 Years</>,
                        value: "6-10 Years",
                      },
                      {
                        id: "11+ Years",
                        label: <>11+ Years</>,
                        value: "11+ Years",
                      },
                      {
                        id: "Not Sure",
                        label: <>Not Sure</>,
                        value: "Not Sure",
                      },
                    ],
                  },
                ],
              ],
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Full System Tune-Up",
    label: <>Full System Tune-Up</>,
    data: [
      [
        {
          name: "memberType",
          question: "Are you a maintenance program member?",
          answers: [
            {
              id: "Yes",
              label: <>Yes</>,
              value: "Yes",
              jobType: "Full System Maintenance/Tune-Up: Member",
            },
            {
              id: "No",
              label: <>No</>,
              value: "No",
              jobType: "Full System Maintenance/Tune-Up: Non-Member",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
      [
        {
          name: "How-many-systems-need-serviced",
          question: "How many systems do you need serviced?",
          answers: [
            {
              id: "One",
              label: <>One</>,
              value: "One",
            },
            {
              id: "Two",
              label: <>Two</>,
              value: "Two",
            },
            {
              id: "Three",
              label: <>Three</>,
              value: "Three",
            },
            {
              id: "Four",
              label: <>Four</>,
              value: "Four",
            },
            {
              id: "Unsure",
              label: <>Unsure</>,
              value: "Unsure",
            },
          ],
        },
      ],
    ],
  },
];
