export const IndoorAirQuality = [
  {
    id: "Installation",
    label: <>Installation</>,
    remType: "estimate",
    data: [
      [
        {
          name: "Installation",
          question: "Installation",
          answers: [
            {
              id: "Air Purifier",
              label: <>Air Purifier</>,
              value: "Air Purifier",
              jobType: "Air Purifier",
            },
            {
              id: "Central Humidifier",
              label: <>Central Humidifier</>,
              value: "Central Humidifier",
              jobType: "Central Humidifier",
            },
            {
              id: "Install Ducts or Vents",
              label: <>Install Ducts or Vents</>,
              value: "Install Ducts or Vents",
              jobType: "Ducts & Vents",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Repair",
    label: <>Repair</>,
    remType: "repair",
    data: [
      [
        {
          name: "Repair",
          question: "Repair",
          answers: [
            {
              id: "Air Purifier",
              label: <>Air Purifier</>,
              value: "Air Purifier",
              jobType: "Air Purifier",
            },
            {
              id: "Central Humidifier",
              label: <>Central Humidifier</>,
              value: "Central Humidifier",
              jobType: "Central Humidifier",
            },
            {
              id: "Repair Ducts or Vents",
              label: <>Repair Ducts or Vents</>,
              value: "Repair Ducts or Vents",
              jobType: "Ducts & Vents",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Maintenance",
    label: <>Maintenance</>,
    remType: "maintenance",
    data: [
      [
        {
          name: "Maintenance",
          question: "Maintenance",
          answers: [
            {
              id: "Duct Cleaning",
              label: <>Duct Cleaning</>,
              value: "Duct Cleaning",
              jobType: "Ducts & Vents",
            },
            {
              id: "Air Purifier",
              label: <>Air Purifier</>,
              value: "Air Purifier",
              jobType: "Air Purifier",
            },
            {
              id: "Central Humidifier",
              label: <>Central Humidifier</>,
              value: "Central Humidifier",
              jobType: "Central Humidifier",
            },
          ],
        },
      ],
    ],
  },
];
