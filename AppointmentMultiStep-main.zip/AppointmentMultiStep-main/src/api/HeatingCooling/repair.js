export const heatingCoolingRepair = [
  {
    id: "No Cooling",
    label: <>No Cooling</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of equipment do you have?",
          answers: [
            {
              id: "Outdoor Mist System",
              label: <>Outdoor Mist System</>,
              value: "Outdoor Mist Cooling System",
              jobType: "Outdoor Mist Cooling System",
            },
            {
              id: "Swamp Cooler",
              label: <>Swamp Cooler</>,
              value: "Swamp Cooler",
              jobType: "Swamp Cooler",
            },
            {
              id: "Heat Pump",
              label: <>Heat Pump</>,
              value: "Heat Pump",
              jobType: "Heat Pump",
            },
            {
              id: "Geo-Thermal",
              label: <>Geo-Thermal</>,
              value: "Geo Thermal Cooling System",
              jobType: "Geo Thermal Cooling System",
            },
            {
              id: "Mini-Split/Ductless",
              label: <>Mini-Split/Ductless</>,
              value: "Ductless Mini-Split A/C",
              jobType: "Ductless Mini-Split A/C",
            },
            {
              id: "Central A/C",
              label: <>Central A/C</>,
              value: "Central A/C",
              jobType: "Central A/C",
            },
            {
              id: "Whole House Fan",
              label: <>Whole House Fan</>,
              value: "Whole House Fan",
              jobType: "Whole House Fan",
            },
            {
              id: "Window A/C Unit",
              label: <>Window A/C Unit</>,
              value: "Window A/C Unit",
              jobType: "Window A/C Unit",
            },
            {
              id: "Unsure",
              label: <>Unsure</>,
              value: "HVAC: Unsure Equipment",
              jobType: "HVAC: Unsure Equipment",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "No Heating",
    label: <>No Heating</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of equipment do you have?",
          answers: [
            {
              id: "Oil Boiler",
              label: <>Oil Boiler</>,
              value: "Oil Boiler",
              jobType: "Oil Boiler",
            },
            {
              id: "Heat Pump",
              label: <>Heat Pump</>,
              value: "Heat Pump",
              jobType: "Heat Pump",
            },
            {
              id: "Geo-Thermal",
              label: <>Geo-Thermal</>,
              value: "Geo-Thermal",
              jobType: "Geo Thermal Heating System",
            },
            {
              id: "Mini-Split/Ductless",
              label: <>Mini-Split/Ductless</>,
              value: "Mini-Split/Ductless",
              jobType: "Ductless Mini-Split A/C",
            },
            {
              id: "Gas Furnace",
              label: <>Gas Furnace</>,
              value: "Gas Furnace",
              jobType: "Gas Furnace",
            },
            {
              id: "Oil Furnace",
              label: <>Oil Furnace</>,
              value: "Oil Furnace",
              jobType: "Oil Furnace",
            },
            {
              id: "Gas Boiler",
              label: <>Gas Boiler</>,
              value: "Gas Boiler",
              jobType: "Gas Boiler",
            },
            {
              id: "Electric Wall Heater",
              label: <>Electric Wall Heater</>,
              value: "Electrical Wall Heater",
              jobType: "Electrical Wall Heater",
            },
            {
              id: "Electric Furnace",
              label: <>Electric Furnace</>,
              value: "Electric Furnace",
              jobType: "Electric Furnace",
            },
            {
              id: "Electric Boiler",
              label: <>Electric Boiler</>,
              value: "Electric Boiler",
              jobType: "Electric Boiler",
            },
            {
              id: "Radiant Floor Heater",
              label: <>Radiant Floor Heater</>,
              value: "Radiant Floor Heating System",
              jobType: "Radiant Floor Heating System",
            },
            {
              id: "Radiant Panel Heater",
              label: <>Radiant Panel Heater</>,
              value: "Radiant Panel Heating Units",
              jobType: "Radiant Panel Heating Units",
            },
            {
              id: "Unsure",
              label: <>Unsure</>,
              value: "HVAC: Unsure Equipment",
              jobType: "HVAC: Unsure Equipment",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Other",
    label: <>Other</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of equipment do you have?",
          answers: [
            {
              id: "Oil Boiler",
              label: <>Oil Boiler</>,
              value: "Oil Boiler",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Heat Pump",
              label: <>Heat Pump</>,
              value: "Heat Pump",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Geo-Thermal",
              label: <>Geo-Thermal</>,
              value: "Geo-Thermal",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Mini-Split/Ductless",
              label: <>Mini-Split/Ductless</>,
              value: "Mini-Split/Ductless",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Gas Furnace",
              label: <>Gas Furnace</>,
              value: "Gas Furnace",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Oil Furnace",
              label: <>Oil Furnace</>,
              value: "Oil Furnace",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Gas Boiler",
              label: <>Gas Boiler</>,
              value: "Gas Boiler",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Electric Wall Heater",
              label: <>Electric Wall Heater</>,
              value: "Electric Wall Heater",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Electric Furnace",
              label: <>Electric Furnace</>,
              value: "Electric Furnace",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Electric Boiler",
              label: <>Electric Boiler</>,
              value: "Electric Boiler",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Radiant Floor Heater",
              label: <>Radiant Floor Heater</>,
              value: "Radiant Floor Heater",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Radiant Panel Heater",
              label: <>Radiant Panel Heater</>,
              value: "Radiant Panel Heater",
              jobType: "HVAC: Other Equipment",
            },
            {
              id: "Unsure",
              label: <>Unsure</>,
              value: "Unsure",
              jobType: "HVAC: Other Equipment",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Water Heaters",
    label: <>Water Heaters</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of water heater do you have?",
          answers: [
            {
              id: "Regular Tank",
              label: <>Regular Tank</>,
              value: "Regular Tank",
              jobType: "Tankless Water Heater: Non-Member",
            },
            {
              id: "Tankless",
              label: <>Tankless</>,
              value: "Tankless Water Heater",
              jobType: "Tankless Water Heater: Non-Member",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
    ],
  },
];
