import { plumbingRepair } from "./Plumbing/repair";
import { electricalRepair } from "./Electrical/repair";
import { heatingCoolingRepair } from "./HeatingCooling/repair";
import { heatingCoolingInstallation } from "./HeatingCooling/Installation";
import { HeatingCoolingMaintenance } from "./HeatingCooling/maintenance";
import { electricalInstallation } from "./Electrical/Installation";
import { ElectricalMaintenance } from "./Electrical/maintenance";
import { plumbingInstallation } from "./Plumbing/Installation";
import { PlumbingMaintenance } from "./Plumbing/maintenance";
import { DrainsSewer } from "./Plumbing/drainsSewer";
import { IndoorAirQuality } from "./HeatingCooling/IndoorAirQuality";

export const serviceTypeList = {
  Plumbing: [
    {
      id: "Water Leak",
      label: <>Water Leak</>,
      icon: (
        <img
          src="/icons/water-leak-repair.svg"
          alt="water-leak-repair-tools"
          title="water-leak-repair-tools"
        />
      ),
      data: [
        {
          id: "Leak",
          label: <>Leak Repair</>,
          remType: "repair",
          jobType: "Leak",
          data: [],
        },
      ],
    },
    {
      id: "Drains & Sewer",
      label: <>Drains & Sewer</>,
      icon: (
        <img
          src="/icons/drains-sewer.svg"
          alt="drains-sewer-tools"
          title="drains-sewer-tools"
        />
      ),
      data: DrainsSewer,
    },
    {
      id: "Repair",
      label: <>Repair</>,
      data: plumbingRepair,
      icon: (
        <img
          src="/icons/plumbing-repair.svg"
          alt="repair-tools"
          title="repair-tools"
        />
      ),
    },
    {
      id: "Estimate",
      label: <>Installation</>,
      icon: (
        <img
          src="/icons/plumbing-installation.svg"
          alt="installation-tools"
          title="installation-tools"
        />
      ),
      data: plumbingInstallation,
    },

    {
      id: "Gas & Gas Lines",
      label: <>Gas & Gas Lines</>,
      icon: (
        <img
          src="/icons/gas-gas-line.svg"
          alt="gas-gas-line-tools"
          title="gas-gas-line-tools"
        />
      ),
      data: [
        {
          id: "Gas Leak Detection & Repair",
          remType: "repair",
          label: <>Gas Leak Detection & Repair</>,
          jobType: "Gas Leak",
          note: (
            <>
              Notice: If applicable, please contact your gas company to have
              your gas shut off prior to scheduling with us."
            </>
          ),
          data: [],
        },
        {
          id: "Gas Line Installation",
          remType: "estimate",
          label: <>Gas Line Installation </>,
          jobType: "Gas Line",
          data: [],
        },
      ],
    },
    {
      id: "Maintenance",
      label: <>Maintenance</>,
      icon: (
        <img
          src="/icons/maintenance.svg"
          alt="maintenance-tools"
          title="maintenance-tools"
        />
      ),
      data: PlumbingMaintenance,
    },
  ],
  "Heating & Cooling": [
    {
      id: "Repair",
      label: <>Repair</>,
      icon: (
        <img
          src="/icons/HVAC-repair.svg"
          alt="HVAC-repair-tools"
          title="HVAC-repair-tools"
        />
      ),
      data: heatingCoolingRepair,
    },

    {
      id: "Estimate",
      label: <>Installation</>,
      icon: (
        <img
          src="/icons/hvac-installation.svg"
          alt="hvac-installation-tools"
          title="hvac-installation-tools"
        />
      ),
      data: heatingCoolingInstallation,
    },
    {
      id: "Maintenance",
      label: <>Maintenance</>,
      icon: (
        <img
          src="/icons/maintenance.svg"
          alt="maintenance-tools"
          title="maintenance-tools"
        />
      ),
      data: HeatingCoolingMaintenance,
    },
    {
      id: "Indoor Air Quality",
      label: <>Indoor Air Quality</>,
      icon: (
        <img
          src="/icons/air-quality.svg"
          alt="air-quality-tools"
          title="air-quality-tools"
        />
      ),
      data: IndoorAirQuality,
    },
  ],
  Electrical: [
    {
      id: "Repair",
      label: <>Repair</>,
      icon: (
        <img
          src="/icons/electrical-repair.svg"
          alt="electrical-repair-tools"
          title="electrical-repair-tools"
        />
      ),
      data: electricalRepair,
    },
    {
      id: "Estimate",
      label: <>Installation</>,
      icon: (
        <img
          src="/icons/electrical-installation.svg"
          alt="electrical-installation-tools"
          title="electrical-installation-tools"
        />
      ),
      data: electricalInstallation,
    },

    {
      id: "Generators",
      label: <>Generators</>,
      icon: (
        <img
          src="/icons/generator.svg"
          alt="generator-tools"
          title="generator-tools"
        />
      ),
      data: [
        {
          id: "New Equipment",
          label: <>New Equipment</>,
          jobType: "Generator",
          remType: "estimate",
          data: [],
        },
        {
          id: "Repair",
          label: <>Repair</>,
          jobType: "Generator",
          remType: "repair",
          data: [],
        },
        {
          id: "Maintenance",
          label: <>Maintenance</>,
          remType: "maintenance",
          data: [
            [
              {
                name: "GeneratorMaintenance",
                question: "Are you a maintenance program member?",
                answers: [
                  {
                    id: "Yes",
                    label: <>Yes</>,
                    value: "Yes",
                    jobType: "Generator: Member",
                  },
                  {
                    id: "No",
                    label: <>No</>,
                    value: "No",
                    jobType: "Generator: Non-Member",
                  },
                ],
              },
            ],
          ],
        },
      ],
    },
    {
      id: "Maintenance",
      label: <>Maintenance</>,
      data: ElectricalMaintenance,
      icon: (
        <img
          src="/icons/maintenance.svg"
          alt="maintenance-tools"
          title="maintenance-tools"
        />
      ),
    },
    {
      id: "Solar",
      label: <>Solar</>,
      icon: (
        <img src="/icons/solar.svg" alt="solar-tools" title="solar-tools" />
      ),
      data: [
        {
          id: "New Equipment",
          label: <>New Equipment</>,
          jobType: "Solar System",
          remType: "estimate",
          data: [],
        },
        {
          id: "Repair",
          label: <>Repair</>,
          jobType: "Solar System",
          remType: "repair",
          data: [],
        },
        {
          id: "Maintenance",
          label: <>Maintenance</>,
          jobType: "Solar System",
          remType: "maintenance",
          data: [],
        },
      ],
    },
  ],
};
