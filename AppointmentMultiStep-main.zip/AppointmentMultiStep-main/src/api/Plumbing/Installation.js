export const plumbingInstallation = [
  {
    id: "Water Heaters",
    label: <>Water Heaters</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of water heater do you have?",
          answers: [
            {
              id: "Regular Tank",
              label: <>Regular Tank</>,
              value: "Water Heater",
              jobType: "Tankless Water Heater: Non-Member",
            },
            {
              id: "Tankless",
              label: <>Tankless</>,
              value: "Tankless Water Heater",
              jobType: "Tankless Water Heater: Non-Member",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
      [
        {
          name: "How-soon-to-installed",
          question: "How soon are you looking to have new equipment installed?",
          answers: [
            {
              id: "This week",
              label: <>This week</>,
              value: "This week",
            },
            {
              id: "Within 30 Days",
              label: <>Within 30 Days</>,
              value: "Within 30 Days",
            },
            {
              id: "Unsure",
              label: <>Unsure</>,
              value: "Unsure",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Septic System",
    label: <>Septic System</>,
    jobType: "Septic System",
    data: [],
  },

  {
    id: "Basement Drainage",
    label: <>Basement Drainage</>,
    jobType: "Basement Drainage Channels",
    data: [],
  },
  {
    id: "Main Sewer Line",
    label: <>Main Sewer Line</>,
    jobType: "Sewer Main",
    data: [],
  },

  {
    id: "Fixtures & Bathroom",
    label: <>Fixtures & Bathroom</>,
    data: [
      [
        {
          name: "fixturesBathroom",
          question: "Fixtures & Bathroom",
          answers: [
            {
              id: "Faucet",
              label: <>Faucet</>,
              value: "Faucet",
              jobType: "Faucets, Fixtures and Pipes",
            },
            {
              id: "Garbage Disposal",
              label: <>Garbage Disposal</>,
              value: "Garbage Disposal",
              jobType: "Garbage Disposal",
            },
            {
              id: "Bathtub",
              label: <>Bathtub</>,
              value: "Bathtub",
              hiddenQuestionData: [
                {
                  name: "bathtub",
                  question: "Bathtub",
                  answers: [
                    {
                      id: "Standard",
                      label: <>Standard</>,
                      value: "Standard",
                      jobType: "Bathtub",
                    },
                    {
                      id: "Walk-In",
                      label: <>Walk-In</>,
                      value: "Walk-In",
                      jobType: "Walk In Bathtub",
                    },
                  ],
                },
              ],
            },
            {
              id: "Shower",
              label: <>Shower</>,
              value: "Shower",
              jobType: "Shower",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Water/Fuel Tank",
    label: <>Water/Fuel Tank</>,
    jobType: "Water or Fuel Tank",
    data: [],
  },
  {
    id: "Sump Pump",
    label: <>Sump Pump</>,
    jobType: "Sump Pump",
    data: [],
  },
  {
    id: "Water Main",
    label: <>Water Main</>,
    jobType: "Water Main",
    data: [],
  },
  {
    id: "Well Pump",
    label: <>Well Pump</>,
    jobType: "Well Pump",
    data: [],
  },
  {
    id: "Backflow Prevention",
    label: <>Backflow Prevention</>,
    jobType: "Backflow Prevention",
    data: [],
  },
  {
    id: "Water Purification",
    label: <>Water Purification</>,
    jobType: "Water Treatment & Purification System",
    data: [],
  },
  {
    id: "Remodel Estimate",
    label: <>Remodel Estimate</>,
    jobType: "Plumbing for a Home Addition or Remodel",
    data: [],
  },
];
