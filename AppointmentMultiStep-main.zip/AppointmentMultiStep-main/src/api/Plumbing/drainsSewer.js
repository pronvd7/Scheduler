export const DrainsSewer = [
  {
    id: "Clogged Drains",
    label: <>Clogged Drains</>,
    remType: "repair",
    data: [
      [
        {
          name: "CloggedDrains",
          question: "How many drains are clogged?",
          answers: [
            {
              id: "One",
              label: <>One</>,
              value: "One",
              jobType: "Drain Clog or Blockage",
            },
            {
              id: "Several",
              label: <>Several</>,
              value: "Several",
              jobType: "Drain Clog or Blockage",
            },
            {
              id: "Entire House",
              label: <>Entire House</>,
              value: "Entire House",
              jobType: "Drain Clog or Blockage",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Broken Drain Line",
    label: <>Broken Drain Line</>,
    remType: "repair",
    jobType: "Drain Line Breakage",
    data: [],
  },
  {
    id: "Sewer Main Line",
    label: <>Sewer Main Line</>,
    remType: "repair",
    data: [
      [
        {
          name: "SewerMainLine",
          question: "Sewer Main Line",
          answers: [
            {
              id: "Clear/Clean",
              label: <>Clear/Clean</>,
              value: "Clear/Clean",
              jobType: "Sewer Main",
            },
            {
              id: "Repair Broken Line",
              label: <>Repair Broken Line</>,
              value: "Repair Broken Line",
              jobType: "Sewer Main",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Basement Drainage",
    label: <>Basement Drainage</>,
    remType: "repair",
    jobType: "Basement Drainage Channels",
    data: [],
  },
];
