export const plumbingRepair = [
  {
    id: "Water Leak",
    label: <>Water Leak</>,
    jobType: "Leak Repair",
    data: [],
  },
  {
    id: "Water Heaters",
    label: <>Water Heaters</>,
    data: [
      [
        {
          name: "equipmentType",
          question: "What kind of water heater do you have?",
          answers: [
            {
              id: "Regular Tank",
              label: <>Regular Tank</>,
              value: "Regular Tank",
              jobType: "Tankless Water Heater: Non-Member",
            },
            {
              id: "Tankless",
              label: <>Tankless</>,
              value: "Tankless Water Heater: Non-Member",
              jobType: "Tankless Water Heater: Non-Member",
            },
          ],
        },
        {
          name: "equipmentAge",
          question: "How old is your equipment?",
          answers: [
            {
              id: "0-5 Years",
              label: <>0-5 Years</>,
              value: "0-5 Years",
            },
            {
              id: "6-10 Years",
              label: <>6-10 Years</>,
              value: "6-10 Years",
            },
            {
              id: "11+ Years",
              label: <>11+ Years</>,
              value: "11+ Years",
            },
            {
              id: "Not Sure",
              label: <>Not Sure</>,
              value: "Not Sure",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Drains & Sewer",
    label: <>Drains & Sewer</>,
    data: [
      [
        {
          name: "Drains & Sewer",
          question: "Drains & Sewer",
          answers: [
            {
              id: "Clogged Drain(s)",
              label: <>Clogged Drain(s)</>,
              value: "Clogged Drain(s)",
              hiddenQuestionData: [
                {
                  name: "How-many-drains-are-clogged",
                  question: "How many drains are clogged?",
                  answers: [
                    {
                      id: "One",
                      label: <>One</>,
                      value: "One",
                      jobType: "Drain Clog or Blockage",
                    },
                    {
                      id: "Several",
                      label: <>Several</>,
                      value: "Several",
                      jobType: "Drain Clog or Blockage",
                    },
                    {
                      id: "Entire House",
                      label: <>Entire House</>,
                      value: "Entire House",
                      jobType: "Drain Clog or Blockage",
                    },
                  ],
                },
              ],
            },
            {
              id: "Broken Drain Line",
              label: <>Broken Drain Line</>,
              value: "Broken Drain Line",
              jobType: "Drain Line Breakage",
            },
            {
              id: "Sewer Main Line",
              label: <>Sewer Main Line</>,
              value: "Sewer Main Line",
              hiddenQuestionData: [
                {
                  name: "Sewer-Main-Line-Type",
                  question: "Sewer Main Line",
                  answers: [
                    {
                      id: "Clear/Clean",
                      label: <>Clear/Clean</>,
                      value: "Clear/Clean",
                      jobType: "Sewer Main",
                    },
                    {
                      id: "Repair Broken Line",
                      label: <>Repair Broken Line</>,
                      value: "Repair Broken Line",
                      jobType: "Sewer Main",
                    },
                  ],
                },
              ],
            },
            {
              id: "Basement Drainage",
              label: <>Basement Drainage</>,
              value: "Basement Drainage",
              jobType: "Basement Drainage Channels",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Fixtures & Bathroom",
    label: <>Fixtures & Bathroom</>,
    data: [
      [
        {
          name: "fixturesBathroom",
          question: "Fixtures & Bathroom",
          answers: [
            {
              id: "Faucet",
              label: <>Faucet</>,
              value: "Faucet",
              jobType: "Faucets, Fixtures and Pipes",
            },
            {
              id: "Garbage Disposal",
              label: <>Garbage Disposal</>,
              value: "Garbage Disposal",
              jobType: "Garbage Disposal",
            },
            {
              id: "Bathtub",
              label: <>Bathtub</>,
              value: "Bathtub",
              jobType: "Faucets, Fixtures and Pipes",
            },
            {
              id: "Shower",
              label: <>Shower</>,
              value: "Shower",
              jobType: "Faucets, Fixtures and Pipes",
            },
          ],
        },
      ],
    ],
  },

  {
    id: "Slab Leak Detection",
    label: <>Slab Leak Detection</>,
    jobType: "Slab Leak",
    data: [],
  },
  {
    id: "Sump Pump",
    label: <>Sump Pump</>,
    jobType: "Sump Pump",
    data: [],
  },
  {
    id: "Backflow Prevention",
    label: <>Backflow Prevention</>,
    jobType: "Backflow Prevention",
    data: [],
  },
  {
    id: "Septic System",
    label: <>Septic System</>,
    jobType: "Septic System",
    data: [],
  },
  {
    id: "Well Pump",
    label: <>Well Pump</>,
    jobType: "Well Pump",
    data: [],
  },
  {
    id: "Water Main",
    label: <>Water Main</>,
    jobType: "Water Main",
    data: [],
  },
];
