export const PlumbingMaintenance = [
  {
    id: "Septic Pumping",
    label: <>Septic Pumping</>,
    jobType: "Septic Tank",
    data: [],
  },

  {
    id: "Water Heater Flush",
    label: <>Water Heater Flush</>,
    data: [
      [
        {
          name: "memberType",
          question: "Are you a maintenance program member?",
          answers: [
            {
              id: "Yes",
              label: <>Yes</>,
              value: "Yes",
              subJobType: "Member",
            },
            {
              id: "No",
              label: <>No</>,
              value: "No",
              subJobType: "Non-Member",
            },
          ],
        },
        {
          name: "equipmentType",
          question: "What kind of water heater Flush do you have?",
          answers: [
            {
              id: "Regular Tank",
              label: <>Regular Tank</>,
              value: "Regular Tank",
              jobType: "Tankless Water Heater: Non-Member",
            },
            {
              id: "Tankless",
              label: <>Tankless</>,
              value: "Tankless Water Heater",
              jobType: "Tankless Water Heater: Non-Member",
            },
          ],
        },
      ],
    ],
  },
  {
    id: "Member Maintenance",
    label: <>Member Maintenance</>,
    jobType: "Water Heater: Member",
    data: [],
  },
  {
    id: "Sump Pumps",
    label: <>Sump Pumps</>,
    jobType: "Sump Pump",
    data: [],
  },
  {
    id: "Well Pump",
    label: <>Well Pump</>,
    jobType: "Well Pump",
    data: [],
  },
];
