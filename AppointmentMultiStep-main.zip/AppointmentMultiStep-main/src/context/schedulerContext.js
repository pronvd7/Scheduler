import React, { createContext, useState, useEffect } from "react";

import { useMutation } from "react-query";
import {
  createTheme,
  responsiveFontSizes,
  ThemeProvider,
} from "@material-ui/core/styles";
import { getSchedulerData } from "../api/services";

// Create the context
const SchedulerContext = createContext();

// Create the context provider
const SchedulerProvider = ({ children }) => {
  const [schedulerData, setSchedulerData] = useState([]);
  const [isSchedulerCompleted, setIsSchedulerCompleted] = useState(false);
  const [theme, setTheme] = useState(
    createTheme({
      palette: {
        primary: {
          main: "#007BFF",
        },
      },
    })
  );

  const {
    mutateAsync: mutateAsyncGetJobsOffered,
    isLoading: schedulerLoading,
  } = useMutation("getSchedulerData", getSchedulerData, {
    onSettled: (data, error) => {
      setIsSchedulerCompleted(true);
      if (error) {
        // Handle mutation error
        console.error("Error fetching data:", error);
      } else {
        // Handle successful mutation result
        if (data?.colorCode !== undefined && data?.colorCode !== "") {
          const updatedTheme = updateTheme(data?.colorCode);
          setTheme(updatedTheme);
        }
        setSchedulerData(data);
      }
    },
  });

  const updateTheme = (siteColor) => {
    let theme = createTheme({
      palette: {
        primary: {
          main: siteColor ? siteColor : "#007BFF",
        },
      },
      typography: {
        htmlFontSize: 16,
        allVariants: {
          fontFamily: ["Poppins", "sans-serif"].join(","),
        },
      },
      overrides: {
        MuiCssBaseline: {
          "@global": {
            "*": {
              "scrollbar-width": "thin",
            },
            "*::-webkit-scrollbar": {
              width: "6px",
              height: "3px",
            },
            "*::-webkit-scrollbar-track": {
              "-webkit-box-shadow": "inset 0 0 6px #E8EDF3",
            },
            "*::-webkit-scrollbar-thumb": {
              backgroundColor: " #B4B9C5",
              outline: "1px solid #B4B9C5",
              borderRadius: "100px",
            },
          },
        },
      },
      components: {
        MuiButton: {
          styleOverrides: {
            input: {
              fontFamily: ["Poppins", "sans-serif"].join(","),
              fontSize: "1rem",
            },
          },
        },
        MuiInputBase: {
          styleOverrides: {
            root: {
              fontFamily: ["Poppins", "sans-serif"].join(","),
              borderRadius: "0.625rem",
            },
          },
        },
        MuiOutlinedInput: {
          input: {
            "&:-webkit-autofill": {
              "-webkit-box-shadow": "0 0 0 100px #000 inset",
              "-webkit-text-fill-color": "#fff",
            },
          },
        },
      },
    });
    return (theme = responsiveFontSizes(theme));
  };

  useEffect(() => {
    // Fetch data from the API
    const fetchData = async () => {
      await mutateAsyncGetJobsOffered();
    };

    fetchData();
  }, []);

  // Define any other state or functions that you want to expose through the context

  return (
    <SchedulerContext.Provider
      value={{ schedulerData, schedulerLoading, isSchedulerCompleted, theme }}
    >
      <ThemeProvider theme={theme}>{children}</ThemeProvider>
    </SchedulerContext.Provider>
  );
};

export { SchedulerContext, SchedulerProvider };
