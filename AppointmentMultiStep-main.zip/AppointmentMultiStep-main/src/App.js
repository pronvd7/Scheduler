import React, { useState } from "react";
import MaterialLayout from "./components/Layout/MaterialLayout";
import AppointmentForm from "./components/AppointmentForm";

function App() {
  const [activeStepColor, setActiveStepColor] = useState("#FFFFFF");
  return (
    <div
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}imag.png)`,
        backgroundColor: "#f5f5f5 !important",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        height: "100vh",
        /*background-position: 50% 50%; /* set your desired background color */
        /* set the height to 100% of the viewport height */
        margin: 0,
        fontFamily: "Poppins",
        minHeight: "100vh",
      }}
    >
      <MaterialLayout activeStepColor={activeStepColor}>
        <AppointmentForm setActiveStepColor={setActiveStepColor} />
      </MaterialLayout>
    </div>
  );
}

export default App;
